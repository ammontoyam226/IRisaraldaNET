﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Servidor
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Servidor))
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.BSalir = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.BDetalleBache = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.BImprimir = New System.Windows.Forms.ToolStripButton()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.TabServidor = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label168 = New System.Windows.Forms.Label()
        Me.TIP1 = New System.Windows.Forms.TextBox()
        Me.BHoraGSE1 = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.BLimpiar1 = New System.Windows.Forms.Button()
        Me.TSeg1 = New System.Windows.Forms.TextBox()
        Me.BPideRep1 = New System.Windows.Forms.Button()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.TEstCon1 = New System.Windows.Forms.TextBox()
        Me.ShRx1 = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TSegSinCon1 = New System.Windows.Forms.TextBox()
        Me.GBDatos = New System.Windows.Forms.GroupBox()
        Me.BRepSac1 = New System.Windows.Forms.Button()
        Me.BBorraRep1 = New System.Windows.Forms.Button()
        Me.BRecRep1 = New System.Windows.Forms.Button()
        Me.TMsg1 = New System.Windows.Forms.TextBox()
        Me.BRecChk1 = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TUsuario1 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TMaq1 = New System.Windows.Forms.TextBox()
        Me.TLote1 = New System.Windows.Forms.TextBox()
        Me.BBorraChk1 = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TFecha1 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TPesoReal1 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TPesoNom1 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TTara1 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TNomProd1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TCodProd1 = New System.Windows.Forms.TextBox()
        Me.CodProd = New System.Windows.Forms.Label()
        Me.BPedirChk1 = New System.Windows.Forms.Button()
        Me.BPruebaCom1 = New System.Windows.Forms.Button()
        Me.TTx1 = New System.Windows.Forms.TextBox()
        Me.TRx1 = New System.Windows.Forms.TextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label169 = New System.Windows.Forms.Label()
        Me.TIP2 = New System.Windows.Forms.TextBox()
        Me.BHoraGSE2 = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.BLimpiar2 = New System.Windows.Forms.Button()
        Me.TSeg2 = New System.Windows.Forms.TextBox()
        Me.BPideRep2 = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TEstCon2 = New System.Windows.Forms.TextBox()
        Me.ShRx2 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.TSegSinCon2 = New System.Windows.Forms.TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.BRecChk2 = New System.Windows.Forms.Button()
        Me.BBorraRep2 = New System.Windows.Forms.Button()
        Me.BRecRep2 = New System.Windows.Forms.Button()
        Me.TMsg2 = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TUsuario2 = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.TMaq2 = New System.Windows.Forms.TextBox()
        Me.TLote2 = New System.Windows.Forms.TextBox()
        Me.BBorraChk2 = New System.Windows.Forms.Button()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.TFecha2 = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.TPesoReal2 = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.TPesoNom2 = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.TTara2 = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.TNomProd2 = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.TCodProd2 = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.BPedirChk2 = New System.Windows.Forms.Button()
        Me.BPruebaCom2 = New System.Windows.Forms.Button()
        Me.TTx2 = New System.Windows.Forms.TextBox()
        Me.TRx2 = New System.Windows.Forms.TextBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label170 = New System.Windows.Forms.Label()
        Me.TIP3 = New System.Windows.Forms.TextBox()
        Me.BHoraGSE3 = New System.Windows.Forms.Button()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.BLimpiar3 = New System.Windows.Forms.Button()
        Me.TSeg3 = New System.Windows.Forms.TextBox()
        Me.BPideRep3 = New System.Windows.Forms.Button()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.TEstCon3 = New System.Windows.Forms.TextBox()
        Me.ShRx3 = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.TSegSinCon3 = New System.Windows.Forms.TextBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.BBorraRep3 = New System.Windows.Forms.Button()
        Me.BRecRep3 = New System.Windows.Forms.Button()
        Me.TMsg3 = New System.Windows.Forms.TextBox()
        Me.BRecChk3 = New System.Windows.Forms.Button()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.TUsuario3 = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.TMaq3 = New System.Windows.Forms.TextBox()
        Me.TLote3 = New System.Windows.Forms.TextBox()
        Me.BBorraChk3 = New System.Windows.Forms.Button()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.TFecha3 = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.TPesoReal3 = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.TPesoNom3 = New System.Windows.Forms.TextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.TTara3 = New System.Windows.Forms.TextBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.TNomProd3 = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.TCodProd3 = New System.Windows.Forms.TextBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.BPedirChk3 = New System.Windows.Forms.Button()
        Me.BPruebaCom3 = New System.Windows.Forms.Button()
        Me.TTx3 = New System.Windows.Forms.TextBox()
        Me.TRx3 = New System.Windows.Forms.TextBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Label171 = New System.Windows.Forms.Label()
        Me.TIP4 = New System.Windows.Forms.TextBox()
        Me.BHoraGSE4 = New System.Windows.Forms.Button()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.BLimpiar4 = New System.Windows.Forms.Button()
        Me.TSeg4 = New System.Windows.Forms.TextBox()
        Me.BPideRep4 = New System.Windows.Forms.Button()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.TEstCon4 = New System.Windows.Forms.TextBox()
        Me.ShRx4 = New System.Windows.Forms.TextBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.TSegSinCon4 = New System.Windows.Forms.TextBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.BBorraRep4 = New System.Windows.Forms.Button()
        Me.BRecRep4 = New System.Windows.Forms.Button()
        Me.TMsg4 = New System.Windows.Forms.TextBox()
        Me.BRecChk4 = New System.Windows.Forms.Button()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.TUsuario4 = New System.Windows.Forms.TextBox()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.TMaq4 = New System.Windows.Forms.TextBox()
        Me.TLote4 = New System.Windows.Forms.TextBox()
        Me.BBorraChk4 = New System.Windows.Forms.Button()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.TFecha4 = New System.Windows.Forms.TextBox()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.TPesoReal4 = New System.Windows.Forms.TextBox()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.TPesoNom4 = New System.Windows.Forms.TextBox()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.TTara4 = New System.Windows.Forms.TextBox()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.TNomProd4 = New System.Windows.Forms.TextBox()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.TCodProd4 = New System.Windows.Forms.TextBox()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.BPedirChk4 = New System.Windows.Forms.Button()
        Me.BPruebaCom4 = New System.Windows.Forms.Button()
        Me.TTx4 = New System.Windows.Forms.TextBox()
        Me.TRx4 = New System.Windows.Forms.TextBox()
        Me.TimSeg = New System.Windows.Forms.Timer(Me.components)
        Me.BRepSac2 = New System.Windows.Forms.Button()
        Me.BRepSac3 = New System.Windows.Forms.Button()
        Me.BRepSac4 = New System.Windows.Forms.Button()
        Me.ToolStrip1.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.TabServidor.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GBDatos.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BSalir, Me.ToolStripSeparator9, Me.BDetalleBache, Me.ToolStripSeparator6, Me.BImprimir})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(813, 25)
        Me.ToolStrip1.TabIndex = 31
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'BSalir
        '
        Me.BSalir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BSalir.Image = CType(resources.GetObject("BSalir.Image"), System.Drawing.Image)
        Me.BSalir.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BSalir.Name = "BSalir"
        Me.BSalir.Size = New System.Drawing.Size(23, 22)
        Me.BSalir.Text = "Salir"
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(6, 25)
        '
        'BDetalleBache
        '
        Me.BDetalleBache.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BDetalleBache.Image = CType(resources.GetObject("BDetalleBache.Image"), System.Drawing.Image)
        Me.BDetalleBache.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BDetalleBache.Name = "BDetalleBache"
        Me.BDetalleBache.Size = New System.Drawing.Size(23, 22)
        Me.BDetalleBache.Text = "Detalles de Bache"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(6, 25)
        '
        'BImprimir
        '
        Me.BImprimir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BImprimir.Image = CType(resources.GetObject("BImprimir.Image"), System.Drawing.Image)
        Me.BImprimir.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BImprimir.Name = "BImprimir"
        Me.BImprimir.Size = New System.Drawing.Size(23, 22)
        Me.BImprimir.Text = "Imprimir Materias Primas"
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 25)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.TabServidor)
        Me.SplitContainer1.Size = New System.Drawing.Size(813, 551)
        Me.SplitContainer1.SplitterDistance = 784
        Me.SplitContainer1.TabIndex = 32
        '
        'TabServidor
        '
        Me.TabServidor.Controls.Add(Me.TabPage1)
        Me.TabServidor.Controls.Add(Me.TabPage2)
        Me.TabServidor.Controls.Add(Me.TabPage3)
        Me.TabServidor.Controls.Add(Me.TabPage4)
        Me.TabServidor.Location = New System.Drawing.Point(7, 3)
        Me.TabServidor.Name = "TabServidor"
        Me.TabServidor.SelectedIndex = 0
        Me.TabServidor.Size = New System.Drawing.Size(774, 519)
        Me.TabServidor.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Button1)
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(766, 493)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "TabPage1"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(731, 143)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(25, 21)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        Me.Button1.Visible = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label168)
        Me.GroupBox1.Controls.Add(Me.TIP1)
        Me.GroupBox1.Controls.Add(Me.BHoraGSE1)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.BLimpiar1)
        Me.GroupBox1.Controls.Add(Me.TSeg1)
        Me.GroupBox1.Controls.Add(Me.BPideRep1)
        Me.GroupBox1.Controls.Add(Me.Label45)
        Me.GroupBox1.Controls.Add(Me.TEstCon1)
        Me.GroupBox1.Controls.Add(Me.ShRx1)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label24)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.TSegSinCon1)
        Me.GroupBox1.Controls.Add(Me.GBDatos)
        Me.GroupBox1.Controls.Add(Me.BPedirChk1)
        Me.GroupBox1.Controls.Add(Me.BPruebaCom1)
        Me.GroupBox1.Controls.Add(Me.TTx1)
        Me.GroupBox1.Controls.Add(Me.TRx1)
        Me.GroupBox1.Location = New System.Drawing.Point(7, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(718, 463)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'Label168
        '
        Me.Label168.AutoSize = True
        Me.Label168.Location = New System.Drawing.Point(123, 15)
        Me.Label168.Name = "Label168"
        Me.Label168.Size = New System.Drawing.Size(17, 13)
        Me.Label168.TabIndex = 169
        Me.Label168.Text = "IP"
        '
        'TIP1
        '
        Me.TIP1.Location = New System.Drawing.Point(146, 11)
        Me.TIP1.Name = "TIP1"
        Me.TIP1.Size = New System.Drawing.Size(100, 20)
        Me.TIP1.TabIndex = 168
        '
        'BHoraGSE1
        '
        Me.BHoraGSE1.Location = New System.Drawing.Point(293, 427)
        Me.BHoraGSE1.Name = "BHoraGSE1"
        Me.BHoraGSE1.Size = New System.Drawing.Size(111, 23)
        Me.BHoraGSE1.TabIndex = 167
        Me.BHoraGSE1.Text = "Actualiza Hora GSE"
        Me.BHoraGSE1.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(527, 13)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(33, 13)
        Me.Label11.TabIndex = 165
        Me.Label11.Text = "TSeg"
        '
        'BLimpiar1
        '
        Me.BLimpiar1.Image = CType(resources.GetObject("BLimpiar1.Image"), System.Drawing.Image)
        Me.BLimpiar1.Location = New System.Drawing.Point(185, 217)
        Me.BLimpiar1.Name = "BLimpiar1"
        Me.BLimpiar1.Size = New System.Drawing.Size(27, 21)
        Me.BLimpiar1.TabIndex = 31
        Me.BLimpiar1.UseVisualStyleBackColor = True
        '
        'TSeg1
        '
        Me.TSeg1.Location = New System.Drawing.Point(565, 9)
        Me.TSeg1.Name = "TSeg1"
        Me.TSeg1.Size = New System.Drawing.Size(45, 20)
        Me.TSeg1.TabIndex = 164
        '
        'BPideRep1
        '
        Me.BPideRep1.Location = New System.Drawing.Point(189, 427)
        Me.BPideRep1.Name = "BPideRep1"
        Me.BPideRep1.Size = New System.Drawing.Size(97, 23)
        Me.BPideRep1.TabIndex = 20
        Me.BPideRep1.Text = "Pide Reportes"
        Me.BPideRep1.UseVisualStyleBackColor = True
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(421, 13)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(43, 13)
        Me.Label45.TabIndex = 163
        Me.Label45.Text = "SinCom"
        '
        'TEstCon1
        '
        Me.TEstCon1.Location = New System.Drawing.Point(670, 9)
        Me.TEstCon1.Name = "TEstCon1"
        Me.TEstCon1.Size = New System.Drawing.Size(20, 20)
        Me.TEstCon1.TabIndex = 162
        '
        'ShRx1
        '
        Me.ShRx1.BackColor = System.Drawing.Color.Silver
        Me.ShRx1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ShRx1.Location = New System.Drawing.Point(700, 13)
        Me.ShRx1.Multiline = True
        Me.ShRx1.Name = "ShRx1"
        Me.ShRx1.ReadOnly = True
        Me.ShRx1.Size = New System.Drawing.Size(13, 13)
        Me.ShRx1.TabIndex = 161
        Me.ShRx1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(7, 222)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(22, 13)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "Tx:"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(634, 13)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(34, 13)
        Me.Label24.TabIndex = 151
        Me.Label24.Text = "Conx:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(7, 20)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(20, 13)
        Me.Label9.TabIndex = 5
        Me.Label9.Text = "Rx"
        '
        'TSegSinCon1
        '
        Me.TSegSinCon1.Location = New System.Drawing.Point(468, 9)
        Me.TSegSinCon1.Name = "TSegSinCon1"
        Me.TSegSinCon1.Size = New System.Drawing.Size(45, 20)
        Me.TSegSinCon1.TabIndex = 18
        '
        'GBDatos
        '
        Me.GBDatos.Controls.Add(Me.BRepSac1)
        Me.GBDatos.Controls.Add(Me.BBorraRep1)
        Me.GBDatos.Controls.Add(Me.BRecRep1)
        Me.GBDatos.Controls.Add(Me.TMsg1)
        Me.GBDatos.Controls.Add(Me.BRecChk1)
        Me.GBDatos.Controls.Add(Me.Label8)
        Me.GBDatos.Controls.Add(Me.TUsuario1)
        Me.GBDatos.Controls.Add(Me.Label7)
        Me.GBDatos.Controls.Add(Me.TMaq1)
        Me.GBDatos.Controls.Add(Me.TLote1)
        Me.GBDatos.Controls.Add(Me.BBorraChk1)
        Me.GBDatos.Controls.Add(Me.Label6)
        Me.GBDatos.Controls.Add(Me.TFecha1)
        Me.GBDatos.Controls.Add(Me.Label5)
        Me.GBDatos.Controls.Add(Me.TPesoReal1)
        Me.GBDatos.Controls.Add(Me.Label4)
        Me.GBDatos.Controls.Add(Me.TPesoNom1)
        Me.GBDatos.Controls.Add(Me.Label3)
        Me.GBDatos.Controls.Add(Me.TTara1)
        Me.GBDatos.Controls.Add(Me.Label2)
        Me.GBDatos.Controls.Add(Me.TNomProd1)
        Me.GBDatos.Controls.Add(Me.Label1)
        Me.GBDatos.Controls.Add(Me.TCodProd1)
        Me.GBDatos.Controls.Add(Me.CodProd)
        Me.GBDatos.Location = New System.Drawing.Point(397, 35)
        Me.GBDatos.Name = "GBDatos"
        Me.GBDatos.Size = New System.Drawing.Size(313, 379)
        Me.GBDatos.TabIndex = 4
        Me.GBDatos.TabStop = False
        Me.GBDatos.Text = "Datos"
        '
        'BRepSac1
        '
        Me.BRepSac1.Location = New System.Drawing.Point(227, 192)
        Me.BRepSac1.Name = "BRepSac1"
        Me.BRepSac1.Size = New System.Drawing.Size(75, 24)
        Me.BRepSac1.TabIndex = 357
        Me.BRepSac1.Text = "BRepSac"
        Me.BRepSac1.UseVisualStyleBackColor = True
        Me.BRepSac1.Visible = False
        '
        'BBorraRep1
        '
        Me.BBorraRep1.Location = New System.Drawing.Point(227, 104)
        Me.BBorraRep1.Name = "BBorraRep1"
        Me.BBorraRep1.Size = New System.Drawing.Size(75, 23)
        Me.BBorraRep1.TabIndex = 22
        Me.BBorraRep1.Text = "BBorraRep"
        Me.BBorraRep1.UseVisualStyleBackColor = True
        Me.BBorraRep1.Visible = False
        '
        'BRecRep1
        '
        Me.BRecRep1.Location = New System.Drawing.Point(227, 81)
        Me.BRecRep1.Name = "BRecRep1"
        Me.BRecRep1.Size = New System.Drawing.Size(75, 23)
        Me.BRecRep1.TabIndex = 21
        Me.BRecRep1.Text = "BRecRep"
        Me.BRecRep1.UseVisualStyleBackColor = True
        Me.BRecRep1.Visible = False
        '
        'TMsg1
        '
        Me.TMsg1.Location = New System.Drawing.Point(10, 249)
        Me.TMsg1.Name = "TMsg1"
        Me.TMsg1.Size = New System.Drawing.Size(192, 20)
        Me.TMsg1.TabIndex = 19
        '
        'BRecChk1
        '
        Me.BRecChk1.Location = New System.Drawing.Point(227, 137)
        Me.BRecChk1.Name = "BRecChk1"
        Me.BRecChk1.Size = New System.Drawing.Size(75, 23)
        Me.BRecChk1.TabIndex = 166
        Me.BRecChk1.Text = "BRecChk"
        Me.BRecChk1.UseVisualStyleBackColor = True
        Me.BRecChk1.Visible = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(7, 227)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(46, 13)
        Me.Label8.TabIndex = 17
        Me.Label8.Text = "Usuario:"
        '
        'TUsuario1
        '
        Me.TUsuario1.Location = New System.Drawing.Point(80, 223)
        Me.TUsuario1.Name = "TUsuario1"
        Me.TUsuario1.Size = New System.Drawing.Size(122, 20)
        Me.TUsuario1.TabIndex = 16
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(7, 179)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(51, 13)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "Máquina:"
        '
        'TMaq1
        '
        Me.TMaq1.Location = New System.Drawing.Point(80, 175)
        Me.TMaq1.Name = "TMaq1"
        Me.TMaq1.Size = New System.Drawing.Size(122, 20)
        Me.TMaq1.TabIndex = 14
        '
        'TLote1
        '
        Me.TLote1.Location = New System.Drawing.Point(80, 199)
        Me.TLote1.Name = "TLote1"
        Me.TLote1.Size = New System.Drawing.Size(122, 20)
        Me.TLote1.TabIndex = 13
        '
        'BBorraChk1
        '
        Me.BBorraChk1.Location = New System.Drawing.Point(227, 160)
        Me.BBorraChk1.Name = "BBorraChk1"
        Me.BBorraChk1.Size = New System.Drawing.Size(75, 23)
        Me.BBorraChk1.TabIndex = 19
        Me.BBorraChk1.Text = "BBorraChk"
        Me.BBorraChk1.UseVisualStyleBackColor = True
        Me.BBorraChk1.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(7, 203)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(31, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Lote:"
        '
        'TFecha1
        '
        Me.TFecha1.Location = New System.Drawing.Point(80, 151)
        Me.TFecha1.Name = "TFecha1"
        Me.TFecha1.Size = New System.Drawing.Size(122, 20)
        Me.TFecha1.TabIndex = 11
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(7, 155)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Fecha:"
        '
        'TPesoReal1
        '
        Me.TPesoReal1.Location = New System.Drawing.Point(80, 127)
        Me.TPesoReal1.Name = "TPesoReal1"
        Me.TPesoReal1.Size = New System.Drawing.Size(122, 20)
        Me.TPesoReal1.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(7, 131)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(59, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Peso Real:"
        '
        'TPesoNom1
        '
        Me.TPesoNom1.Location = New System.Drawing.Point(80, 103)
        Me.TPesoNom1.Name = "TPesoNom1"
        Me.TPesoNom1.Size = New System.Drawing.Size(122, 20)
        Me.TPesoNom1.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(7, 107)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(75, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Peso Nominal:"
        '
        'TTara1
        '
        Me.TTara1.Location = New System.Drawing.Point(80, 79)
        Me.TTara1.Name = "TTara1"
        Me.TTara1.Size = New System.Drawing.Size(122, 20)
        Me.TTara1.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(7, 83)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Tara:"
        '
        'TNomProd1
        '
        Me.TNomProd1.Location = New System.Drawing.Point(80, 55)
        Me.TNomProd1.Name = "TNomProd1"
        Me.TNomProd1.Size = New System.Drawing.Size(222, 20)
        Me.TNomProd1.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 59)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Nombre:"
        '
        'TCodProd1
        '
        Me.TCodProd1.Location = New System.Drawing.Point(80, 31)
        Me.TCodProd1.Name = "TCodProd1"
        Me.TCodProd1.Size = New System.Drawing.Size(122, 20)
        Me.TCodProd1.TabIndex = 1
        '
        'CodProd
        '
        Me.CodProd.AutoSize = True
        Me.CodProd.Location = New System.Drawing.Point(7, 35)
        Me.CodProd.Name = "CodProd"
        Me.CodProd.Size = New System.Drawing.Size(51, 13)
        Me.CodProd.TabIndex = 0
        Me.CodProd.Text = "CodProd:"
        '
        'BPedirChk1
        '
        Me.BPedirChk1.Location = New System.Drawing.Point(85, 427)
        Me.BPedirChk1.Name = "BPedirChk1"
        Me.BPedirChk1.Size = New System.Drawing.Size(97, 23)
        Me.BPedirChk1.TabIndex = 3
        Me.BPedirChk1.Text = "PedirChk"
        Me.BPedirChk1.UseVisualStyleBackColor = True
        '
        'BPruebaCom1
        '
        Me.BPruebaCom1.Location = New System.Drawing.Point(7, 427)
        Me.BPruebaCom1.Name = "BPruebaCom1"
        Me.BPruebaCom1.Size = New System.Drawing.Size(71, 23)
        Me.BPruebaCom1.TabIndex = 2
        Me.BPruebaCom1.Text = "PruebaCom"
        Me.BPruebaCom1.UseVisualStyleBackColor = True
        '
        'TTx1
        '
        Me.TTx1.Location = New System.Drawing.Point(7, 243)
        Me.TTx1.Multiline = True
        Me.TTx1.Name = "TTx1"
        Me.TTx1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TTx1.Size = New System.Drawing.Size(383, 170)
        Me.TTx1.TabIndex = 1
        '
        'TRx1
        '
        Me.TRx1.Location = New System.Drawing.Point(7, 41)
        Me.TRx1.Multiline = True
        Me.TRx1.Name = "TRx1"
        Me.TRx1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TRx1.Size = New System.Drawing.Size(383, 170)
        Me.TRx1.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.GroupBox2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(766, 493)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "TabPage2"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label169)
        Me.GroupBox2.Controls.Add(Me.TIP2)
        Me.GroupBox2.Controls.Add(Me.BHoraGSE2)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.BLimpiar2)
        Me.GroupBox2.Controls.Add(Me.TSeg2)
        Me.GroupBox2.Controls.Add(Me.BPideRep2)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.TEstCon2)
        Me.GroupBox2.Controls.Add(Me.ShRx2)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.Label16)
        Me.GroupBox2.Controls.Add(Me.TSegSinCon2)
        Me.GroupBox2.Controls.Add(Me.GroupBox3)
        Me.GroupBox2.Controls.Add(Me.BPedirChk2)
        Me.GroupBox2.Controls.Add(Me.BPruebaCom2)
        Me.GroupBox2.Controls.Add(Me.TTx2)
        Me.GroupBox2.Controls.Add(Me.TRx2)
        Me.GroupBox2.Location = New System.Drawing.Point(7, 6)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(718, 463)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        '
        'Label169
        '
        Me.Label169.AutoSize = True
        Me.Label169.Location = New System.Drawing.Point(148, 17)
        Me.Label169.Name = "Label169"
        Me.Label169.Size = New System.Drawing.Size(17, 13)
        Me.Label169.TabIndex = 171
        Me.Label169.Text = "IP"
        '
        'TIP2
        '
        Me.TIP2.Location = New System.Drawing.Point(171, 13)
        Me.TIP2.Name = "TIP2"
        Me.TIP2.Size = New System.Drawing.Size(100, 20)
        Me.TIP2.TabIndex = 170
        '
        'BHoraGSE2
        '
        Me.BHoraGSE2.Location = New System.Drawing.Point(293, 427)
        Me.BHoraGSE2.Name = "BHoraGSE2"
        Me.BHoraGSE2.Size = New System.Drawing.Size(111, 23)
        Me.BHoraGSE2.TabIndex = 168
        Me.BHoraGSE2.Text = "Actualiza Hora GSE"
        Me.BHoraGSE2.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(527, 13)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(33, 13)
        Me.Label12.TabIndex = 165
        Me.Label12.Text = "TSeg"
        '
        'BLimpiar2
        '
        Me.BLimpiar2.Image = CType(resources.GetObject("BLimpiar2.Image"), System.Drawing.Image)
        Me.BLimpiar2.Location = New System.Drawing.Point(185, 217)
        Me.BLimpiar2.Name = "BLimpiar2"
        Me.BLimpiar2.Size = New System.Drawing.Size(27, 21)
        Me.BLimpiar2.TabIndex = 31
        Me.BLimpiar2.UseVisualStyleBackColor = True
        '
        'TSeg2
        '
        Me.TSeg2.Location = New System.Drawing.Point(565, 9)
        Me.TSeg2.Name = "TSeg2"
        Me.TSeg2.Size = New System.Drawing.Size(45, 20)
        Me.TSeg2.TabIndex = 164
        '
        'BPideRep2
        '
        Me.BPideRep2.Location = New System.Drawing.Point(189, 427)
        Me.BPideRep2.Name = "BPideRep2"
        Me.BPideRep2.Size = New System.Drawing.Size(97, 23)
        Me.BPideRep2.TabIndex = 20
        Me.BPideRep2.Text = "Pide Reportes"
        Me.BPideRep2.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(421, 13)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(43, 13)
        Me.Label13.TabIndex = 163
        Me.Label13.Text = "SinCom"
        '
        'TEstCon2
        '
        Me.TEstCon2.Location = New System.Drawing.Point(670, 9)
        Me.TEstCon2.Name = "TEstCon2"
        Me.TEstCon2.Size = New System.Drawing.Size(20, 20)
        Me.TEstCon2.TabIndex = 162
        '
        'ShRx2
        '
        Me.ShRx2.BackColor = System.Drawing.Color.Silver
        Me.ShRx2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ShRx2.Location = New System.Drawing.Point(700, 13)
        Me.ShRx2.Multiline = True
        Me.ShRx2.Name = "ShRx2"
        Me.ShRx2.ReadOnly = True
        Me.ShRx2.Size = New System.Drawing.Size(13, 13)
        Me.ShRx2.TabIndex = 161
        Me.ShRx2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(7, 222)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(22, 13)
        Me.Label14.TabIndex = 18
        Me.Label14.Text = "Tx:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(634, 13)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(34, 13)
        Me.Label15.TabIndex = 151
        Me.Label15.Text = "Conx:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(7, 20)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(20, 13)
        Me.Label16.TabIndex = 5
        Me.Label16.Text = "Rx"
        '
        'TSegSinCon2
        '
        Me.TSegSinCon2.Location = New System.Drawing.Point(468, 9)
        Me.TSegSinCon2.Name = "TSegSinCon2"
        Me.TSegSinCon2.Size = New System.Drawing.Size(45, 20)
        Me.TSegSinCon2.TabIndex = 18
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.BRepSac2)
        Me.GroupBox3.Controls.Add(Me.BRecChk2)
        Me.GroupBox3.Controls.Add(Me.BBorraRep2)
        Me.GroupBox3.Controls.Add(Me.BRecRep2)
        Me.GroupBox3.Controls.Add(Me.TMsg2)
        Me.GroupBox3.Controls.Add(Me.Label17)
        Me.GroupBox3.Controls.Add(Me.TUsuario2)
        Me.GroupBox3.Controls.Add(Me.Label18)
        Me.GroupBox3.Controls.Add(Me.TMaq2)
        Me.GroupBox3.Controls.Add(Me.TLote2)
        Me.GroupBox3.Controls.Add(Me.BBorraChk2)
        Me.GroupBox3.Controls.Add(Me.Label19)
        Me.GroupBox3.Controls.Add(Me.TFecha2)
        Me.GroupBox3.Controls.Add(Me.Label20)
        Me.GroupBox3.Controls.Add(Me.TPesoReal2)
        Me.GroupBox3.Controls.Add(Me.Label21)
        Me.GroupBox3.Controls.Add(Me.TPesoNom2)
        Me.GroupBox3.Controls.Add(Me.Label22)
        Me.GroupBox3.Controls.Add(Me.TTara2)
        Me.GroupBox3.Controls.Add(Me.Label23)
        Me.GroupBox3.Controls.Add(Me.TNomProd2)
        Me.GroupBox3.Controls.Add(Me.Label25)
        Me.GroupBox3.Controls.Add(Me.TCodProd2)
        Me.GroupBox3.Controls.Add(Me.Label26)
        Me.GroupBox3.Location = New System.Drawing.Point(397, 34)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(313, 379)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Datos"
        '
        'BRecChk2
        '
        Me.BRecChk2.Location = New System.Drawing.Point(227, 137)
        Me.BRecChk2.Name = "BRecChk2"
        Me.BRecChk2.Size = New System.Drawing.Size(75, 23)
        Me.BRecChk2.TabIndex = 167
        Me.BRecChk2.Text = "BRecChk"
        Me.BRecChk2.UseVisualStyleBackColor = True
        Me.BRecChk2.Visible = False
        '
        'BBorraRep2
        '
        Me.BBorraRep2.Location = New System.Drawing.Point(227, 104)
        Me.BBorraRep2.Name = "BBorraRep2"
        Me.BBorraRep2.Size = New System.Drawing.Size(75, 23)
        Me.BBorraRep2.TabIndex = 24
        Me.BBorraRep2.Text = "BBorraRep"
        Me.BBorraRep2.UseVisualStyleBackColor = True
        Me.BBorraRep2.Visible = False
        '
        'BRecRep2
        '
        Me.BRecRep2.Location = New System.Drawing.Point(227, 81)
        Me.BRecRep2.Name = "BRecRep2"
        Me.BRecRep2.Size = New System.Drawing.Size(75, 23)
        Me.BRecRep2.TabIndex = 23
        Me.BRecRep2.Text = "BRecRep"
        Me.BRecRep2.UseVisualStyleBackColor = True
        Me.BRecRep2.Visible = False
        '
        'TMsg2
        '
        Me.TMsg2.Location = New System.Drawing.Point(10, 249)
        Me.TMsg2.Name = "TMsg2"
        Me.TMsg2.Size = New System.Drawing.Size(192, 20)
        Me.TMsg2.TabIndex = 19
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(7, 227)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(46, 13)
        Me.Label17.TabIndex = 17
        Me.Label17.Text = "Usuario:"
        '
        'TUsuario2
        '
        Me.TUsuario2.Location = New System.Drawing.Point(80, 223)
        Me.TUsuario2.Name = "TUsuario2"
        Me.TUsuario2.Size = New System.Drawing.Size(122, 20)
        Me.TUsuario2.TabIndex = 16
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(7, 179)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(51, 13)
        Me.Label18.TabIndex = 15
        Me.Label18.Text = "Máquina:"
        '
        'TMaq2
        '
        Me.TMaq2.Location = New System.Drawing.Point(80, 175)
        Me.TMaq2.Name = "TMaq2"
        Me.TMaq2.Size = New System.Drawing.Size(122, 20)
        Me.TMaq2.TabIndex = 14
        '
        'TLote2
        '
        Me.TLote2.Location = New System.Drawing.Point(80, 199)
        Me.TLote2.Name = "TLote2"
        Me.TLote2.Size = New System.Drawing.Size(122, 20)
        Me.TLote2.TabIndex = 13
        '
        'BBorraChk2
        '
        Me.BBorraChk2.Location = New System.Drawing.Point(227, 160)
        Me.BBorraChk2.Name = "BBorraChk2"
        Me.BBorraChk2.Size = New System.Drawing.Size(75, 23)
        Me.BBorraChk2.TabIndex = 19
        Me.BBorraChk2.Text = "BBorraChk"
        Me.BBorraChk2.UseVisualStyleBackColor = True
        Me.BBorraChk2.Visible = False
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(7, 203)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(31, 13)
        Me.Label19.TabIndex = 12
        Me.Label19.Text = "Lote:"
        '
        'TFecha2
        '
        Me.TFecha2.Location = New System.Drawing.Point(80, 151)
        Me.TFecha2.Name = "TFecha2"
        Me.TFecha2.Size = New System.Drawing.Size(122, 20)
        Me.TFecha2.TabIndex = 11
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(7, 155)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(40, 13)
        Me.Label20.TabIndex = 10
        Me.Label20.Text = "Fecha:"
        '
        'TPesoReal2
        '
        Me.TPesoReal2.Location = New System.Drawing.Point(80, 127)
        Me.TPesoReal2.Name = "TPesoReal2"
        Me.TPesoReal2.Size = New System.Drawing.Size(122, 20)
        Me.TPesoReal2.TabIndex = 9
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(7, 131)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(59, 13)
        Me.Label21.TabIndex = 8
        Me.Label21.Text = "Peso Real:"
        '
        'TPesoNom2
        '
        Me.TPesoNom2.Location = New System.Drawing.Point(80, 103)
        Me.TPesoNom2.Name = "TPesoNom2"
        Me.TPesoNom2.Size = New System.Drawing.Size(122, 20)
        Me.TPesoNom2.TabIndex = 7
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(7, 107)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(75, 13)
        Me.Label22.TabIndex = 6
        Me.Label22.Text = "Peso Nominal:"
        '
        'TTara2
        '
        Me.TTara2.Location = New System.Drawing.Point(80, 79)
        Me.TTara2.Name = "TTara2"
        Me.TTara2.Size = New System.Drawing.Size(122, 20)
        Me.TTara2.TabIndex = 5
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(7, 83)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(32, 13)
        Me.Label23.TabIndex = 4
        Me.Label23.Text = "Tara:"
        '
        'TNomProd2
        '
        Me.TNomProd2.Location = New System.Drawing.Point(80, 55)
        Me.TNomProd2.Name = "TNomProd2"
        Me.TNomProd2.Size = New System.Drawing.Size(222, 20)
        Me.TNomProd2.TabIndex = 3
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(7, 59)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(47, 13)
        Me.Label25.TabIndex = 2
        Me.Label25.Text = "Nombre:"
        '
        'TCodProd2
        '
        Me.TCodProd2.Location = New System.Drawing.Point(80, 31)
        Me.TCodProd2.Name = "TCodProd2"
        Me.TCodProd2.Size = New System.Drawing.Size(122, 20)
        Me.TCodProd2.TabIndex = 1
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(7, 35)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(51, 13)
        Me.Label26.TabIndex = 0
        Me.Label26.Text = "CodProd:"
        '
        'BPedirChk2
        '
        Me.BPedirChk2.Location = New System.Drawing.Point(85, 427)
        Me.BPedirChk2.Name = "BPedirChk2"
        Me.BPedirChk2.Size = New System.Drawing.Size(97, 23)
        Me.BPedirChk2.TabIndex = 3
        Me.BPedirChk2.Text = "PedirChk"
        Me.BPedirChk2.UseVisualStyleBackColor = True
        '
        'BPruebaCom2
        '
        Me.BPruebaCom2.Location = New System.Drawing.Point(7, 427)
        Me.BPruebaCom2.Name = "BPruebaCom2"
        Me.BPruebaCom2.Size = New System.Drawing.Size(71, 23)
        Me.BPruebaCom2.TabIndex = 2
        Me.BPruebaCom2.Text = "PruebaCom"
        Me.BPruebaCom2.UseVisualStyleBackColor = True
        '
        'TTx2
        '
        Me.TTx2.Location = New System.Drawing.Point(7, 243)
        Me.TTx2.Multiline = True
        Me.TTx2.Name = "TTx2"
        Me.TTx2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TTx2.Size = New System.Drawing.Size(383, 170)
        Me.TTx2.TabIndex = 1
        '
        'TRx2
        '
        Me.TRx2.Location = New System.Drawing.Point(7, 41)
        Me.TRx2.Multiline = True
        Me.TRx2.Name = "TRx2"
        Me.TRx2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TRx2.Size = New System.Drawing.Size(383, 170)
        Me.TRx2.TabIndex = 0
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.GroupBox4)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(766, 493)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "TabPage3"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label170)
        Me.GroupBox4.Controls.Add(Me.TIP3)
        Me.GroupBox4.Controls.Add(Me.BHoraGSE3)
        Me.GroupBox4.Controls.Add(Me.Label27)
        Me.GroupBox4.Controls.Add(Me.BLimpiar3)
        Me.GroupBox4.Controls.Add(Me.TSeg3)
        Me.GroupBox4.Controls.Add(Me.BPideRep3)
        Me.GroupBox4.Controls.Add(Me.Label28)
        Me.GroupBox4.Controls.Add(Me.TEstCon3)
        Me.GroupBox4.Controls.Add(Me.ShRx3)
        Me.GroupBox4.Controls.Add(Me.Label29)
        Me.GroupBox4.Controls.Add(Me.Label30)
        Me.GroupBox4.Controls.Add(Me.Label31)
        Me.GroupBox4.Controls.Add(Me.TSegSinCon3)
        Me.GroupBox4.Controls.Add(Me.GroupBox5)
        Me.GroupBox4.Controls.Add(Me.BPedirChk3)
        Me.GroupBox4.Controls.Add(Me.BPruebaCom3)
        Me.GroupBox4.Controls.Add(Me.TTx3)
        Me.GroupBox4.Controls.Add(Me.TRx3)
        Me.GroupBox4.Location = New System.Drawing.Point(7, 6)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(718, 463)
        Me.GroupBox4.TabIndex = 2
        Me.GroupBox4.TabStop = False
        '
        'Label170
        '
        Me.Label170.AutoSize = True
        Me.Label170.Location = New System.Drawing.Point(162, 19)
        Me.Label170.Name = "Label170"
        Me.Label170.Size = New System.Drawing.Size(17, 13)
        Me.Label170.TabIndex = 171
        Me.Label170.Text = "IP"
        '
        'TIP3
        '
        Me.TIP3.Location = New System.Drawing.Point(185, 15)
        Me.TIP3.Name = "TIP3"
        Me.TIP3.Size = New System.Drawing.Size(100, 20)
        Me.TIP3.TabIndex = 170
        '
        'BHoraGSE3
        '
        Me.BHoraGSE3.Location = New System.Drawing.Point(293, 427)
        Me.BHoraGSE3.Name = "BHoraGSE3"
        Me.BHoraGSE3.Size = New System.Drawing.Size(111, 23)
        Me.BHoraGSE3.TabIndex = 169
        Me.BHoraGSE3.Text = "Actualiza Hora GSE"
        Me.BHoraGSE3.UseVisualStyleBackColor = True
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(527, 13)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(33, 13)
        Me.Label27.TabIndex = 165
        Me.Label27.Text = "TSeg"
        '
        'BLimpiar3
        '
        Me.BLimpiar3.Image = CType(resources.GetObject("BLimpiar3.Image"), System.Drawing.Image)
        Me.BLimpiar3.Location = New System.Drawing.Point(185, 217)
        Me.BLimpiar3.Name = "BLimpiar3"
        Me.BLimpiar3.Size = New System.Drawing.Size(27, 21)
        Me.BLimpiar3.TabIndex = 31
        Me.BLimpiar3.UseVisualStyleBackColor = True
        '
        'TSeg3
        '
        Me.TSeg3.Location = New System.Drawing.Point(565, 9)
        Me.TSeg3.Name = "TSeg3"
        Me.TSeg3.Size = New System.Drawing.Size(45, 20)
        Me.TSeg3.TabIndex = 164
        '
        'BPideRep3
        '
        Me.BPideRep3.Location = New System.Drawing.Point(189, 427)
        Me.BPideRep3.Name = "BPideRep3"
        Me.BPideRep3.Size = New System.Drawing.Size(97, 23)
        Me.BPideRep3.TabIndex = 20
        Me.BPideRep3.Text = "Pide Reportes"
        Me.BPideRep3.UseVisualStyleBackColor = True
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(421, 13)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(43, 13)
        Me.Label28.TabIndex = 163
        Me.Label28.Text = "SinCom"
        '
        'TEstCon3
        '
        Me.TEstCon3.Location = New System.Drawing.Point(670, 9)
        Me.TEstCon3.Name = "TEstCon3"
        Me.TEstCon3.Size = New System.Drawing.Size(20, 20)
        Me.TEstCon3.TabIndex = 162
        '
        'ShRx3
        '
        Me.ShRx3.BackColor = System.Drawing.Color.Silver
        Me.ShRx3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ShRx3.Location = New System.Drawing.Point(700, 13)
        Me.ShRx3.Multiline = True
        Me.ShRx3.Name = "ShRx3"
        Me.ShRx3.ReadOnly = True
        Me.ShRx3.Size = New System.Drawing.Size(13, 13)
        Me.ShRx3.TabIndex = 161
        Me.ShRx3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(7, 222)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(22, 13)
        Me.Label29.TabIndex = 18
        Me.Label29.Text = "Tx:"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(634, 13)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(34, 13)
        Me.Label30.TabIndex = 151
        Me.Label30.Text = "Conx:"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(7, 20)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(20, 13)
        Me.Label31.TabIndex = 5
        Me.Label31.Text = "Rx"
        '
        'TSegSinCon3
        '
        Me.TSegSinCon3.Location = New System.Drawing.Point(468, 9)
        Me.TSegSinCon3.Name = "TSegSinCon3"
        Me.TSegSinCon3.Size = New System.Drawing.Size(45, 20)
        Me.TSegSinCon3.TabIndex = 18
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.BRepSac3)
        Me.GroupBox5.Controls.Add(Me.BBorraRep3)
        Me.GroupBox5.Controls.Add(Me.BRecRep3)
        Me.GroupBox5.Controls.Add(Me.TMsg3)
        Me.GroupBox5.Controls.Add(Me.BRecChk3)
        Me.GroupBox5.Controls.Add(Me.Label32)
        Me.GroupBox5.Controls.Add(Me.TUsuario3)
        Me.GroupBox5.Controls.Add(Me.Label33)
        Me.GroupBox5.Controls.Add(Me.TMaq3)
        Me.GroupBox5.Controls.Add(Me.TLote3)
        Me.GroupBox5.Controls.Add(Me.BBorraChk3)
        Me.GroupBox5.Controls.Add(Me.Label34)
        Me.GroupBox5.Controls.Add(Me.TFecha3)
        Me.GroupBox5.Controls.Add(Me.Label35)
        Me.GroupBox5.Controls.Add(Me.TPesoReal3)
        Me.GroupBox5.Controls.Add(Me.Label36)
        Me.GroupBox5.Controls.Add(Me.TPesoNom3)
        Me.GroupBox5.Controls.Add(Me.Label37)
        Me.GroupBox5.Controls.Add(Me.TTara3)
        Me.GroupBox5.Controls.Add(Me.Label38)
        Me.GroupBox5.Controls.Add(Me.TNomProd3)
        Me.GroupBox5.Controls.Add(Me.Label39)
        Me.GroupBox5.Controls.Add(Me.TCodProd3)
        Me.GroupBox5.Controls.Add(Me.Label40)
        Me.GroupBox5.Location = New System.Drawing.Point(397, 34)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(313, 379)
        Me.GroupBox5.TabIndex = 4
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Datos"
        '
        'BBorraRep3
        '
        Me.BBorraRep3.Location = New System.Drawing.Point(227, 104)
        Me.BBorraRep3.Name = "BBorraRep3"
        Me.BBorraRep3.Size = New System.Drawing.Size(75, 23)
        Me.BBorraRep3.TabIndex = 22
        Me.BBorraRep3.Text = "BBorraRep"
        Me.BBorraRep3.UseVisualStyleBackColor = True
        Me.BBorraRep3.Visible = False
        '
        'BRecRep3
        '
        Me.BRecRep3.Location = New System.Drawing.Point(227, 81)
        Me.BRecRep3.Name = "BRecRep3"
        Me.BRecRep3.Size = New System.Drawing.Size(75, 23)
        Me.BRecRep3.TabIndex = 21
        Me.BRecRep3.Text = "BRecRep"
        Me.BRecRep3.UseVisualStyleBackColor = True
        Me.BRecRep3.Visible = False
        '
        'TMsg3
        '
        Me.TMsg3.Location = New System.Drawing.Point(10, 249)
        Me.TMsg3.Name = "TMsg3"
        Me.TMsg3.Size = New System.Drawing.Size(192, 20)
        Me.TMsg3.TabIndex = 19
        '
        'BRecChk3
        '
        Me.BRecChk3.Location = New System.Drawing.Point(227, 137)
        Me.BRecChk3.Name = "BRecChk3"
        Me.BRecChk3.Size = New System.Drawing.Size(75, 23)
        Me.BRecChk3.TabIndex = 168
        Me.BRecChk3.Text = "BRecChk"
        Me.BRecChk3.UseVisualStyleBackColor = True
        Me.BRecChk3.Visible = False
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(7, 227)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(46, 13)
        Me.Label32.TabIndex = 17
        Me.Label32.Text = "Usuario:"
        '
        'TUsuario3
        '
        Me.TUsuario3.Location = New System.Drawing.Point(80, 223)
        Me.TUsuario3.Name = "TUsuario3"
        Me.TUsuario3.Size = New System.Drawing.Size(122, 20)
        Me.TUsuario3.TabIndex = 16
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(7, 179)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(51, 13)
        Me.Label33.TabIndex = 15
        Me.Label33.Text = "Máquina:"
        '
        'TMaq3
        '
        Me.TMaq3.Location = New System.Drawing.Point(80, 175)
        Me.TMaq3.Name = "TMaq3"
        Me.TMaq3.Size = New System.Drawing.Size(122, 20)
        Me.TMaq3.TabIndex = 14
        '
        'TLote3
        '
        Me.TLote3.Location = New System.Drawing.Point(80, 199)
        Me.TLote3.Name = "TLote3"
        Me.TLote3.Size = New System.Drawing.Size(122, 20)
        Me.TLote3.TabIndex = 13
        '
        'BBorraChk3
        '
        Me.BBorraChk3.Location = New System.Drawing.Point(227, 160)
        Me.BBorraChk3.Name = "BBorraChk3"
        Me.BBorraChk3.Size = New System.Drawing.Size(75, 23)
        Me.BBorraChk3.TabIndex = 19
        Me.BBorraChk3.Text = "BBorraChk"
        Me.BBorraChk3.UseVisualStyleBackColor = True
        Me.BBorraChk3.Visible = False
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(7, 203)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(31, 13)
        Me.Label34.TabIndex = 12
        Me.Label34.Text = "Lote:"
        '
        'TFecha3
        '
        Me.TFecha3.Location = New System.Drawing.Point(80, 151)
        Me.TFecha3.Name = "TFecha3"
        Me.TFecha3.Size = New System.Drawing.Size(122, 20)
        Me.TFecha3.TabIndex = 11
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(7, 155)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(40, 13)
        Me.Label35.TabIndex = 10
        Me.Label35.Text = "Fecha:"
        '
        'TPesoReal3
        '
        Me.TPesoReal3.Location = New System.Drawing.Point(80, 127)
        Me.TPesoReal3.Name = "TPesoReal3"
        Me.TPesoReal3.Size = New System.Drawing.Size(122, 20)
        Me.TPesoReal3.TabIndex = 9
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(7, 131)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(59, 13)
        Me.Label36.TabIndex = 8
        Me.Label36.Text = "Peso Real:"
        '
        'TPesoNom3
        '
        Me.TPesoNom3.Location = New System.Drawing.Point(80, 103)
        Me.TPesoNom3.Name = "TPesoNom3"
        Me.TPesoNom3.Size = New System.Drawing.Size(122, 20)
        Me.TPesoNom3.TabIndex = 7
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(7, 107)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(75, 13)
        Me.Label37.TabIndex = 6
        Me.Label37.Text = "Peso Nominal:"
        '
        'TTara3
        '
        Me.TTara3.Location = New System.Drawing.Point(80, 79)
        Me.TTara3.Name = "TTara3"
        Me.TTara3.Size = New System.Drawing.Size(122, 20)
        Me.TTara3.TabIndex = 5
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(7, 83)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(32, 13)
        Me.Label38.TabIndex = 4
        Me.Label38.Text = "Tara:"
        '
        'TNomProd3
        '
        Me.TNomProd3.Location = New System.Drawing.Point(80, 55)
        Me.TNomProd3.Name = "TNomProd3"
        Me.TNomProd3.Size = New System.Drawing.Size(222, 20)
        Me.TNomProd3.TabIndex = 3
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(7, 59)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(47, 13)
        Me.Label39.TabIndex = 2
        Me.Label39.Text = "Nombre:"
        '
        'TCodProd3
        '
        Me.TCodProd3.Location = New System.Drawing.Point(80, 31)
        Me.TCodProd3.Name = "TCodProd3"
        Me.TCodProd3.Size = New System.Drawing.Size(122, 20)
        Me.TCodProd3.TabIndex = 1
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(7, 35)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(51, 13)
        Me.Label40.TabIndex = 0
        Me.Label40.Text = "CodProd:"
        '
        'BPedirChk3
        '
        Me.BPedirChk3.Location = New System.Drawing.Point(85, 427)
        Me.BPedirChk3.Name = "BPedirChk3"
        Me.BPedirChk3.Size = New System.Drawing.Size(97, 23)
        Me.BPedirChk3.TabIndex = 3
        Me.BPedirChk3.Text = "BPedirChk3"
        Me.BPedirChk3.UseVisualStyleBackColor = True
        '
        'BPruebaCom3
        '
        Me.BPruebaCom3.Location = New System.Drawing.Point(7, 427)
        Me.BPruebaCom3.Name = "BPruebaCom3"
        Me.BPruebaCom3.Size = New System.Drawing.Size(71, 23)
        Me.BPruebaCom3.TabIndex = 2
        Me.BPruebaCom3.Text = "PruebaCom"
        Me.BPruebaCom3.UseVisualStyleBackColor = True
        '
        'TTx3
        '
        Me.TTx3.Location = New System.Drawing.Point(7, 243)
        Me.TTx3.Multiline = True
        Me.TTx3.Name = "TTx3"
        Me.TTx3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TTx3.Size = New System.Drawing.Size(383, 170)
        Me.TTx3.TabIndex = 1
        '
        'TRx3
        '
        Me.TRx3.Location = New System.Drawing.Point(7, 41)
        Me.TRx3.Multiline = True
        Me.TRx3.Name = "TRx3"
        Me.TRx3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TRx3.Size = New System.Drawing.Size(383, 170)
        Me.TRx3.TabIndex = 0
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.GroupBox6)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(766, 493)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "TabPage4"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.Label171)
        Me.GroupBox6.Controls.Add(Me.TIP4)
        Me.GroupBox6.Controls.Add(Me.BHoraGSE4)
        Me.GroupBox6.Controls.Add(Me.Label41)
        Me.GroupBox6.Controls.Add(Me.BLimpiar4)
        Me.GroupBox6.Controls.Add(Me.TSeg4)
        Me.GroupBox6.Controls.Add(Me.BPideRep4)
        Me.GroupBox6.Controls.Add(Me.Label42)
        Me.GroupBox6.Controls.Add(Me.TEstCon4)
        Me.GroupBox6.Controls.Add(Me.ShRx4)
        Me.GroupBox6.Controls.Add(Me.Label43)
        Me.GroupBox6.Controls.Add(Me.Label44)
        Me.GroupBox6.Controls.Add(Me.Label46)
        Me.GroupBox6.Controls.Add(Me.TSegSinCon4)
        Me.GroupBox6.Controls.Add(Me.GroupBox7)
        Me.GroupBox6.Controls.Add(Me.BPedirChk4)
        Me.GroupBox6.Controls.Add(Me.BPruebaCom4)
        Me.GroupBox6.Controls.Add(Me.TTx4)
        Me.GroupBox6.Controls.Add(Me.TRx4)
        Me.GroupBox6.Location = New System.Drawing.Point(7, 6)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(718, 463)
        Me.GroupBox6.TabIndex = 2
        Me.GroupBox6.TabStop = False
        '
        'Label171
        '
        Me.Label171.AutoSize = True
        Me.Label171.Location = New System.Drawing.Point(167, 18)
        Me.Label171.Name = "Label171"
        Me.Label171.Size = New System.Drawing.Size(17, 13)
        Me.Label171.TabIndex = 172
        Me.Label171.Text = "IP"
        '
        'TIP4
        '
        Me.TIP4.Location = New System.Drawing.Point(190, 14)
        Me.TIP4.Name = "TIP4"
        Me.TIP4.Size = New System.Drawing.Size(100, 20)
        Me.TIP4.TabIndex = 171
        '
        'BHoraGSE4
        '
        Me.BHoraGSE4.Location = New System.Drawing.Point(293, 427)
        Me.BHoraGSE4.Name = "BHoraGSE4"
        Me.BHoraGSE4.Size = New System.Drawing.Size(111, 23)
        Me.BHoraGSE4.TabIndex = 170
        Me.BHoraGSE4.Text = "Actualiza Hora GSE"
        Me.BHoraGSE4.UseVisualStyleBackColor = True
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(527, 13)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(33, 13)
        Me.Label41.TabIndex = 165
        Me.Label41.Text = "TSeg"
        '
        'BLimpiar4
        '
        Me.BLimpiar4.Image = CType(resources.GetObject("BLimpiar4.Image"), System.Drawing.Image)
        Me.BLimpiar4.Location = New System.Drawing.Point(185, 217)
        Me.BLimpiar4.Name = "BLimpiar4"
        Me.BLimpiar4.Size = New System.Drawing.Size(27, 21)
        Me.BLimpiar4.TabIndex = 31
        Me.BLimpiar4.UseVisualStyleBackColor = True
        '
        'TSeg4
        '
        Me.TSeg4.Location = New System.Drawing.Point(565, 9)
        Me.TSeg4.Name = "TSeg4"
        Me.TSeg4.Size = New System.Drawing.Size(45, 20)
        Me.TSeg4.TabIndex = 164
        '
        'BPideRep4
        '
        Me.BPideRep4.Location = New System.Drawing.Point(189, 427)
        Me.BPideRep4.Name = "BPideRep4"
        Me.BPideRep4.Size = New System.Drawing.Size(97, 23)
        Me.BPideRep4.TabIndex = 20
        Me.BPideRep4.Text = "Pide Reportes"
        Me.BPideRep4.UseVisualStyleBackColor = True
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(421, 13)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(43, 13)
        Me.Label42.TabIndex = 163
        Me.Label42.Text = "SinCom"
        '
        'TEstCon4
        '
        Me.TEstCon4.Location = New System.Drawing.Point(670, 9)
        Me.TEstCon4.Name = "TEstCon4"
        Me.TEstCon4.Size = New System.Drawing.Size(20, 20)
        Me.TEstCon4.TabIndex = 162
        '
        'ShRx4
        '
        Me.ShRx4.BackColor = System.Drawing.Color.Silver
        Me.ShRx4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ShRx4.Location = New System.Drawing.Point(700, 13)
        Me.ShRx4.Multiline = True
        Me.ShRx4.Name = "ShRx4"
        Me.ShRx4.ReadOnly = True
        Me.ShRx4.Size = New System.Drawing.Size(13, 13)
        Me.ShRx4.TabIndex = 161
        Me.ShRx4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(7, 222)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(22, 13)
        Me.Label43.TabIndex = 18
        Me.Label43.Text = "Tx:"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(634, 13)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(34, 13)
        Me.Label44.TabIndex = 151
        Me.Label44.Text = "Conx:"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(7, 20)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(20, 13)
        Me.Label46.TabIndex = 5
        Me.Label46.Text = "Rx"
        '
        'TSegSinCon4
        '
        Me.TSegSinCon4.Location = New System.Drawing.Point(468, 9)
        Me.TSegSinCon4.Name = "TSegSinCon4"
        Me.TSegSinCon4.Size = New System.Drawing.Size(45, 20)
        Me.TSegSinCon4.TabIndex = 18
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.BRepSac4)
        Me.GroupBox7.Controls.Add(Me.BBorraRep4)
        Me.GroupBox7.Controls.Add(Me.BRecRep4)
        Me.GroupBox7.Controls.Add(Me.TMsg4)
        Me.GroupBox7.Controls.Add(Me.BRecChk4)
        Me.GroupBox7.Controls.Add(Me.Label47)
        Me.GroupBox7.Controls.Add(Me.TUsuario4)
        Me.GroupBox7.Controls.Add(Me.Label48)
        Me.GroupBox7.Controls.Add(Me.TMaq4)
        Me.GroupBox7.Controls.Add(Me.TLote4)
        Me.GroupBox7.Controls.Add(Me.BBorraChk4)
        Me.GroupBox7.Controls.Add(Me.Label49)
        Me.GroupBox7.Controls.Add(Me.TFecha4)
        Me.GroupBox7.Controls.Add(Me.Label50)
        Me.GroupBox7.Controls.Add(Me.TPesoReal4)
        Me.GroupBox7.Controls.Add(Me.Label51)
        Me.GroupBox7.Controls.Add(Me.TPesoNom4)
        Me.GroupBox7.Controls.Add(Me.Label52)
        Me.GroupBox7.Controls.Add(Me.TTara4)
        Me.GroupBox7.Controls.Add(Me.Label53)
        Me.GroupBox7.Controls.Add(Me.TNomProd4)
        Me.GroupBox7.Controls.Add(Me.Label54)
        Me.GroupBox7.Controls.Add(Me.TCodProd4)
        Me.GroupBox7.Controls.Add(Me.Label55)
        Me.GroupBox7.Location = New System.Drawing.Point(397, 34)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(313, 379)
        Me.GroupBox7.TabIndex = 4
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Datos"
        '
        'BBorraRep4
        '
        Me.BBorraRep4.Location = New System.Drawing.Point(227, 104)
        Me.BBorraRep4.Name = "BBorraRep4"
        Me.BBorraRep4.Size = New System.Drawing.Size(75, 23)
        Me.BBorraRep4.TabIndex = 22
        Me.BBorraRep4.Text = "BBorraRep"
        Me.BBorraRep4.UseVisualStyleBackColor = True
        Me.BBorraRep4.Visible = False
        '
        'BRecRep4
        '
        Me.BRecRep4.Location = New System.Drawing.Point(227, 81)
        Me.BRecRep4.Name = "BRecRep4"
        Me.BRecRep4.Size = New System.Drawing.Size(75, 23)
        Me.BRecRep4.TabIndex = 21
        Me.BRecRep4.Text = "BRecRep"
        Me.BRecRep4.UseVisualStyleBackColor = True
        Me.BRecRep4.Visible = False
        '
        'TMsg4
        '
        Me.TMsg4.Location = New System.Drawing.Point(10, 249)
        Me.TMsg4.Name = "TMsg4"
        Me.TMsg4.Size = New System.Drawing.Size(192, 20)
        Me.TMsg4.TabIndex = 19
        '
        'BRecChk4
        '
        Me.BRecChk4.Location = New System.Drawing.Point(227, 137)
        Me.BRecChk4.Name = "BRecChk4"
        Me.BRecChk4.Size = New System.Drawing.Size(75, 23)
        Me.BRecChk4.TabIndex = 169
        Me.BRecChk4.Text = "BRecChk"
        Me.BRecChk4.UseVisualStyleBackColor = True
        Me.BRecChk4.Visible = False
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(7, 227)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(46, 13)
        Me.Label47.TabIndex = 17
        Me.Label47.Text = "Usuario:"
        '
        'TUsuario4
        '
        Me.TUsuario4.Location = New System.Drawing.Point(80, 223)
        Me.TUsuario4.Name = "TUsuario4"
        Me.TUsuario4.Size = New System.Drawing.Size(122, 20)
        Me.TUsuario4.TabIndex = 16
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(7, 179)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(51, 13)
        Me.Label48.TabIndex = 15
        Me.Label48.Text = "Máquina:"
        '
        'TMaq4
        '
        Me.TMaq4.Location = New System.Drawing.Point(80, 175)
        Me.TMaq4.Name = "TMaq4"
        Me.TMaq4.Size = New System.Drawing.Size(122, 20)
        Me.TMaq4.TabIndex = 14
        '
        'TLote4
        '
        Me.TLote4.Location = New System.Drawing.Point(80, 199)
        Me.TLote4.Name = "TLote4"
        Me.TLote4.Size = New System.Drawing.Size(122, 20)
        Me.TLote4.TabIndex = 13
        '
        'BBorraChk4
        '
        Me.BBorraChk4.Location = New System.Drawing.Point(227, 160)
        Me.BBorraChk4.Name = "BBorraChk4"
        Me.BBorraChk4.Size = New System.Drawing.Size(75, 23)
        Me.BBorraChk4.TabIndex = 19
        Me.BBorraChk4.Text = "BBorraChk"
        Me.BBorraChk4.UseVisualStyleBackColor = True
        Me.BBorraChk4.Visible = False
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(7, 203)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(31, 13)
        Me.Label49.TabIndex = 12
        Me.Label49.Text = "Lote:"
        '
        'TFecha4
        '
        Me.TFecha4.Location = New System.Drawing.Point(80, 151)
        Me.TFecha4.Name = "TFecha4"
        Me.TFecha4.Size = New System.Drawing.Size(122, 20)
        Me.TFecha4.TabIndex = 11
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(7, 155)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(40, 13)
        Me.Label50.TabIndex = 10
        Me.Label50.Text = "Fecha:"
        '
        'TPesoReal4
        '
        Me.TPesoReal4.Location = New System.Drawing.Point(80, 127)
        Me.TPesoReal4.Name = "TPesoReal4"
        Me.TPesoReal4.Size = New System.Drawing.Size(122, 20)
        Me.TPesoReal4.TabIndex = 9
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(7, 131)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(59, 13)
        Me.Label51.TabIndex = 8
        Me.Label51.Text = "Peso Real:"
        '
        'TPesoNom4
        '
        Me.TPesoNom4.Location = New System.Drawing.Point(80, 103)
        Me.TPesoNom4.Name = "TPesoNom4"
        Me.TPesoNom4.Size = New System.Drawing.Size(122, 20)
        Me.TPesoNom4.TabIndex = 7
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(7, 107)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(75, 13)
        Me.Label52.TabIndex = 6
        Me.Label52.Text = "Peso Nominal:"
        '
        'TTara4
        '
        Me.TTara4.Location = New System.Drawing.Point(80, 79)
        Me.TTara4.Name = "TTara4"
        Me.TTara4.Size = New System.Drawing.Size(122, 20)
        Me.TTara4.TabIndex = 5
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(7, 83)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(32, 13)
        Me.Label53.TabIndex = 4
        Me.Label53.Text = "Tara:"
        '
        'TNomProd4
        '
        Me.TNomProd4.Location = New System.Drawing.Point(80, 55)
        Me.TNomProd4.Name = "TNomProd4"
        Me.TNomProd4.Size = New System.Drawing.Size(222, 20)
        Me.TNomProd4.TabIndex = 3
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(7, 59)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(47, 13)
        Me.Label54.TabIndex = 2
        Me.Label54.Text = "Nombre:"
        '
        'TCodProd4
        '
        Me.TCodProd4.Location = New System.Drawing.Point(80, 31)
        Me.TCodProd4.Name = "TCodProd4"
        Me.TCodProd4.Size = New System.Drawing.Size(122, 20)
        Me.TCodProd4.TabIndex = 1
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(7, 35)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(51, 13)
        Me.Label55.TabIndex = 0
        Me.Label55.Text = "CodProd:"
        '
        'BPedirChk4
        '
        Me.BPedirChk4.Location = New System.Drawing.Point(85, 427)
        Me.BPedirChk4.Name = "BPedirChk4"
        Me.BPedirChk4.Size = New System.Drawing.Size(97, 23)
        Me.BPedirChk4.TabIndex = 3
        Me.BPedirChk4.Text = "BPedirChk4"
        Me.BPedirChk4.UseVisualStyleBackColor = True
        '
        'BPruebaCom4
        '
        Me.BPruebaCom4.Location = New System.Drawing.Point(7, 427)
        Me.BPruebaCom4.Name = "BPruebaCom4"
        Me.BPruebaCom4.Size = New System.Drawing.Size(71, 23)
        Me.BPruebaCom4.TabIndex = 2
        Me.BPruebaCom4.Text = "PruebaCom"
        Me.BPruebaCom4.UseVisualStyleBackColor = True
        '
        'TTx4
        '
        Me.TTx4.Location = New System.Drawing.Point(7, 243)
        Me.TTx4.Multiline = True
        Me.TTx4.Name = "TTx4"
        Me.TTx4.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TTx4.Size = New System.Drawing.Size(383, 170)
        Me.TTx4.TabIndex = 1
        '
        'TRx4
        '
        Me.TRx4.Location = New System.Drawing.Point(7, 41)
        Me.TRx4.Multiline = True
        Me.TRx4.Name = "TRx4"
        Me.TRx4.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TRx4.Size = New System.Drawing.Size(383, 170)
        Me.TRx4.TabIndex = 0
        '
        'TimSeg
        '
        Me.TimSeg.Interval = 1000
        '
        'BRepSac2
        '
        Me.BRepSac2.Location = New System.Drawing.Point(227, 192)
        Me.BRepSac2.Name = "BRepSac2"
        Me.BRepSac2.Size = New System.Drawing.Size(75, 24)
        Me.BRepSac2.TabIndex = 358
        Me.BRepSac2.Text = "BRepSac"
        Me.BRepSac2.UseVisualStyleBackColor = True
        Me.BRepSac2.Visible = False
        '
        'BRepSac3
        '
        Me.BRepSac3.Location = New System.Drawing.Point(227, 192)
        Me.BRepSac3.Name = "BRepSac3"
        Me.BRepSac3.Size = New System.Drawing.Size(75, 24)
        Me.BRepSac3.TabIndex = 359
        Me.BRepSac3.Text = "BRepSac"
        Me.BRepSac3.UseVisualStyleBackColor = True
        Me.BRepSac3.Visible = False
        '
        'BRepSac4
        '
        Me.BRepSac4.Location = New System.Drawing.Point(227, 192)
        Me.BRepSac4.Name = "BRepSac4"
        Me.BRepSac4.Size = New System.Drawing.Size(75, 24)
        Me.BRepSac4.TabIndex = 360
        Me.BRepSac4.Text = "BRepSac"
        Me.BRepSac4.UseVisualStyleBackColor = True
        Me.BRepSac4.Visible = False
        '
        'Servidor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(813, 576)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Servidor"
        Me.Text = "Servidor"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.TabServidor.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GBDatos.ResumeLayout(False)
        Me.GBDatos.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents BSalir As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator9 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BImprimir As System.Windows.Forms.ToolStripButton
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents TimSeg As System.Windows.Forms.Timer
    Friend WithEvents BDetalleBache As System.Windows.Forms.ToolStripButton
    Friend WithEvents TabServidor As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label168 As System.Windows.Forms.Label
    Friend WithEvents TIP1 As System.Windows.Forms.TextBox
    Friend WithEvents BHoraGSE1 As System.Windows.Forms.Button
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents BLimpiar1 As System.Windows.Forms.Button
    Friend WithEvents TSeg1 As System.Windows.Forms.TextBox
    Friend WithEvents BPideRep1 As System.Windows.Forms.Button
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents TEstCon1 As System.Windows.Forms.TextBox
    Friend WithEvents ShRx1 As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TSegSinCon1 As System.Windows.Forms.TextBox
    Friend WithEvents GBDatos As System.Windows.Forms.GroupBox
    Friend WithEvents BBorraRep1 As System.Windows.Forms.Button
    Friend WithEvents BRecRep1 As System.Windows.Forms.Button
    Friend WithEvents TMsg1 As System.Windows.Forms.TextBox
    Friend WithEvents BRecChk1 As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TUsuario1 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TMaq1 As System.Windows.Forms.TextBox
    Friend WithEvents TLote1 As System.Windows.Forms.TextBox
    Friend WithEvents BBorraChk1 As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TFecha1 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TPesoReal1 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TPesoNom1 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TTara1 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TNomProd1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TCodProd1 As System.Windows.Forms.TextBox
    Friend WithEvents CodProd As System.Windows.Forms.Label
    Friend WithEvents BPedirChk1 As System.Windows.Forms.Button
    Friend WithEvents BPruebaCom1 As System.Windows.Forms.Button
    Friend WithEvents TTx1 As System.Windows.Forms.TextBox
    Friend WithEvents TRx1 As System.Windows.Forms.TextBox
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label169 As System.Windows.Forms.Label
    Friend WithEvents TIP2 As System.Windows.Forms.TextBox
    Friend WithEvents BHoraGSE2 As System.Windows.Forms.Button
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents BLimpiar2 As System.Windows.Forms.Button
    Friend WithEvents TSeg2 As System.Windows.Forms.TextBox
    Friend WithEvents BPideRep2 As System.Windows.Forms.Button
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents TEstCon2 As System.Windows.Forms.TextBox
    Friend WithEvents ShRx2 As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents TSegSinCon2 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents BRecChk2 As System.Windows.Forms.Button
    Friend WithEvents BBorraRep2 As System.Windows.Forms.Button
    Friend WithEvents BRecRep2 As System.Windows.Forms.Button
    Friend WithEvents TMsg2 As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents TUsuario2 As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents TMaq2 As System.Windows.Forms.TextBox
    Friend WithEvents TLote2 As System.Windows.Forms.TextBox
    Friend WithEvents BBorraChk2 As System.Windows.Forms.Button
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents TFecha2 As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents TPesoReal2 As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents TPesoNom2 As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents TTara2 As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents TNomProd2 As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents TCodProd2 As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents BPedirChk2 As System.Windows.Forms.Button
    Friend WithEvents BPruebaCom2 As System.Windows.Forms.Button
    Friend WithEvents TTx2 As System.Windows.Forms.TextBox
    Friend WithEvents TRx2 As System.Windows.Forms.TextBox
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label170 As System.Windows.Forms.Label
    Friend WithEvents TIP3 As System.Windows.Forms.TextBox
    Friend WithEvents BHoraGSE3 As System.Windows.Forms.Button
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents BLimpiar3 As System.Windows.Forms.Button
    Friend WithEvents TSeg3 As System.Windows.Forms.TextBox
    Friend WithEvents BPideRep3 As System.Windows.Forms.Button
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents TEstCon3 As System.Windows.Forms.TextBox
    Friend WithEvents ShRx3 As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents TSegSinCon3 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents BBorraRep3 As System.Windows.Forms.Button
    Friend WithEvents BRecRep3 As System.Windows.Forms.Button
    Friend WithEvents TMsg3 As System.Windows.Forms.TextBox
    Friend WithEvents BRecChk3 As System.Windows.Forms.Button
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents TUsuario3 As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents TMaq3 As System.Windows.Forms.TextBox
    Friend WithEvents TLote3 As System.Windows.Forms.TextBox
    Friend WithEvents BBorraChk3 As System.Windows.Forms.Button
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents TFecha3 As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents TPesoReal3 As System.Windows.Forms.TextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents TPesoNom3 As System.Windows.Forms.TextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents TTara3 As System.Windows.Forms.TextBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents TNomProd3 As System.Windows.Forms.TextBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents TCodProd3 As System.Windows.Forms.TextBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents BPedirChk3 As System.Windows.Forms.Button
    Friend WithEvents BPruebaCom3 As System.Windows.Forms.Button
    Friend WithEvents TTx3 As System.Windows.Forms.TextBox
    Friend WithEvents TRx3 As System.Windows.Forms.TextBox
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents Label171 As System.Windows.Forms.Label
    Friend WithEvents TIP4 As System.Windows.Forms.TextBox
    Friend WithEvents BHoraGSE4 As System.Windows.Forms.Button
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents BLimpiar4 As System.Windows.Forms.Button
    Friend WithEvents TSeg4 As System.Windows.Forms.TextBox
    Friend WithEvents BPideRep4 As System.Windows.Forms.Button
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents TEstCon4 As System.Windows.Forms.TextBox
    Friend WithEvents ShRx4 As System.Windows.Forms.TextBox
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents TSegSinCon4 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents BBorraRep4 As System.Windows.Forms.Button
    Friend WithEvents BRecRep4 As System.Windows.Forms.Button
    Friend WithEvents TMsg4 As System.Windows.Forms.TextBox
    Friend WithEvents BRecChk4 As System.Windows.Forms.Button
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents TUsuario4 As System.Windows.Forms.TextBox
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents TMaq4 As System.Windows.Forms.TextBox
    Friend WithEvents TLote4 As System.Windows.Forms.TextBox
    Friend WithEvents BBorraChk4 As System.Windows.Forms.Button
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents TFecha4 As System.Windows.Forms.TextBox
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents TPesoReal4 As System.Windows.Forms.TextBox
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents TPesoNom4 As System.Windows.Forms.TextBox
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents TTara4 As System.Windows.Forms.TextBox
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents TNomProd4 As System.Windows.Forms.TextBox
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents TCodProd4 As System.Windows.Forms.TextBox
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents BPedirChk4 As System.Windows.Forms.Button
    Friend WithEvents BPruebaCom4 As System.Windows.Forms.Button
    Friend WithEvents TTx4 As System.Windows.Forms.TextBox
    Friend WithEvents TRx4 As System.Windows.Forms.TextBox
    Friend WithEvents BRepSac1 As System.Windows.Forms.Button
    Friend WithEvents BRepSac2 As System.Windows.Forms.Button
    Friend WithEvents BRepSac3 As System.Windows.Forms.Button
    Friend WithEvents BRepSac4 As System.Windows.Forms.Button
End Class
