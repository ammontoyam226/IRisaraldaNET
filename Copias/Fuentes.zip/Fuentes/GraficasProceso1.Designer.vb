﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GraficasProceso1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ChartArea1 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Series1 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Title1 As System.Windows.Forms.DataVisualization.Charting.Title = New System.Windows.Forms.DataVisualization.Charting.Title()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(GraficasProceso1))
        Dim ChartArea2 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Series2 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Title2 As System.Windows.Forms.DataVisualization.Charting.Title = New System.Windows.Forms.DataVisualization.Charting.Title()
        Dim ChartArea3 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Series3 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Title3 As System.Windows.Forms.DataVisualization.Charting.Title = New System.Windows.Forms.DataVisualization.Charting.Title()
        Dim ChartArea4 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Series4 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Title4 As System.Windows.Forms.DataVisualization.Charting.Title = New System.Windows.Forms.DataVisualization.Charting.Title()
        Dim ChartArea5 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Series5 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Title5 As System.Windows.Forms.DataVisualization.Charting.Title = New System.Windows.Forms.DataVisualization.Charting.Title()
        Dim ChartArea6 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Series6 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Title6 As System.Windows.Forms.DataVisualization.Charting.Title = New System.Windows.Forms.DataVisualization.Charting.Title()
        Me.TPGraficos = New System.Windows.Forms.TableLayoutPanel()
        Me.ChDatos1 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.BNext6 = New System.Windows.Forms.Button()
        Me.BPrevious6 = New System.Windows.Forms.Button()
        Me.TFechaIni6 = New System.Windows.Forms.TextBox()
        Me.TFechaFin6 = New System.Windows.Forms.TextBox()
        Me.TMuestrasDia6 = New System.Windows.Forms.TextBox()
        Me.TMuestrasGraf6 = New System.Windows.Forms.TextBox()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.BNext3 = New System.Windows.Forms.Button()
        Me.BPrevious3 = New System.Windows.Forms.Button()
        Me.TFechaIni3 = New System.Windows.Forms.TextBox()
        Me.TFechaFin3 = New System.Windows.Forms.TextBox()
        Me.TMuestrasDia3 = New System.Windows.Forms.TextBox()
        Me.TMuestrasGraf3 = New System.Windows.Forms.TextBox()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.ChDatos6 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.BNext5 = New System.Windows.Forms.Button()
        Me.BPrevious5 = New System.Windows.Forms.Button()
        Me.TFechaIni5 = New System.Windows.Forms.TextBox()
        Me.TFechaFin5 = New System.Windows.Forms.TextBox()
        Me.TMuestrasDia5 = New System.Windows.Forms.TextBox()
        Me.TMuestrasGraf5 = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.BNext2 = New System.Windows.Forms.Button()
        Me.BPrevious2 = New System.Windows.Forms.Button()
        Me.TFechaIni2 = New System.Windows.Forms.TextBox()
        Me.TFechaFin2 = New System.Windows.Forms.TextBox()
        Me.TMuestrasDia2 = New System.Windows.Forms.TextBox()
        Me.TMuestrasGraf2 = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ChDatos3 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.ChDatos5 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.ChDatos2 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.ChDatos4 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.BNext4 = New System.Windows.Forms.Button()
        Me.BPrevious4 = New System.Windows.Forms.Button()
        Me.TFechaIni4 = New System.Windows.Forms.TextBox()
        Me.TFechaFin4 = New System.Windows.Forms.TextBox()
        Me.TMuestrasDia4 = New System.Windows.Forms.TextBox()
        Me.TMuestrasGraf4 = New System.Windows.Forms.TextBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.BNext1 = New System.Windows.Forms.Button()
        Me.BPrevious1 = New System.Windows.Forms.Button()
        Me.TFechaIni1 = New System.Windows.Forms.TextBox()
        Me.TFechaFin1 = New System.Windows.Forms.TextBox()
        Me.TMuestrasDia1 = New System.Windows.Forms.TextBox()
        Me.TMuestrasGraf1 = New System.Windows.Forms.TextBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TimSeg = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.OPHora1 = New System.Windows.Forms.RadioButton()
        Me.OPHora8 = New System.Windows.Forms.RadioButton()
        Me.OPHora4 = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.BPlay = New System.Windows.Forms.Button()
        Me.TPGraficos.SuspendLayout()
        CType(Me.ChDatos1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel12.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.Panel9.SuspendLayout()
        CType(Me.ChDatos6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel8.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.ChDatos3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ChDatos5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ChDatos2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ChDatos4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel6.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TPGraficos
        '
        Me.TPGraficos.ColumnCount = 2
        Me.TPGraficos.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TPGraficos.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TPGraficos.Controls.Add(Me.ChDatos1, 0, 0)
        Me.TPGraficos.Controls.Add(Me.Panel12, 1, 8)
        Me.TPGraficos.Controls.Add(Me.Panel11, 0, 8)
        Me.TPGraficos.Controls.Add(Me.Panel10, 1, 7)
        Me.TPGraficos.Controls.Add(Me.Panel9, 0, 7)
        Me.TPGraficos.Controls.Add(Me.ChDatos6, 1, 6)
        Me.TPGraficos.Controls.Add(Me.Panel8, 1, 4)
        Me.TPGraficos.Controls.Add(Me.Panel7, 1, 5)
        Me.TPGraficos.Controls.Add(Me.Panel2, 0, 5)
        Me.TPGraficos.Controls.Add(Me.Panel1, 0, 4)
        Me.TPGraficos.Controls.Add(Me.ChDatos3, 0, 6)
        Me.TPGraficos.Controls.Add(Me.ChDatos5, 1, 3)
        Me.TPGraficos.Controls.Add(Me.ChDatos2, 0, 3)
        Me.TPGraficos.Controls.Add(Me.ChDatos4, 1, 0)
        Me.TPGraficos.Controls.Add(Me.Panel6, 1, 1)
        Me.TPGraficos.Controls.Add(Me.Panel5, 1, 2)
        Me.TPGraficos.Controls.Add(Me.Panel4, 0, 2)
        Me.TPGraficos.Controls.Add(Me.Panel3, 0, 1)
        Me.TPGraficos.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TPGraficos.Location = New System.Drawing.Point(0, 32)
        Me.TPGraficos.Name = "TPGraficos"
        Me.TPGraficos.RowCount = 9
        Me.TPGraficos.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 190.0!))
        Me.TPGraficos.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15.0!))
        Me.TPGraficos.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TPGraficos.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 190.0!))
        Me.TPGraficos.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15.0!))
        Me.TPGraficos.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TPGraficos.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 190.0!))
        Me.TPGraficos.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15.0!))
        Me.TPGraficos.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TPGraficos.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TPGraficos.Size = New System.Drawing.Size(1008, 697)
        Me.TPGraficos.TabIndex = 32
        '
        'ChDatos1
        '
        Me.ChDatos1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ChDatos1.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.DiagonalRight
        ChartArea1.AxisX.IsLabelAutoFit = False
        ChartArea1.AxisX.MajorGrid.Enabled = False
        ChartArea1.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash
        ChartArea1.AxisX2.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash
        ChartArea1.AxisX2.MajorTickMark.Enabled = False
        ChartArea1.AxisY.MajorGrid.Enabled = False
        ChartArea1.Name = "ChartArea1"
        Me.ChDatos1.ChartAreas.Add(ChartArea1)
        Me.ChDatos1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ChDatos1.Location = New System.Drawing.Point(3, 3)
        Me.ChDatos1.Name = "ChDatos1"
        Me.ChDatos1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Bright
        Series1.BorderWidth = 3
        Series1.ChartArea = "ChartArea1"
        Series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine
        Series1.IsValueShownAsLabel = True
        Series1.IsVisibleInLegend = False
        Series1.Name = "Series1"
        Me.ChDatos1.Series.Add(Series1)
        Me.ChDatos1.Size = New System.Drawing.Size(498, 184)
        Me.ChDatos1.TabIndex = 23
        Title1.DockedToChartArea = "ChartArea1"
        Title1.Name = "Title1"
        Me.ChDatos1.Titles.Add(Title1)
        '
        'Panel12
        '
        Me.Panel12.Controls.Add(Me.BNext6)
        Me.Panel12.Controls.Add(Me.BPrevious6)
        Me.Panel12.Controls.Add(Me.TFechaIni6)
        Me.Panel12.Controls.Add(Me.TFechaFin6)
        Me.Panel12.Controls.Add(Me.TMuestrasDia6)
        Me.Panel12.Controls.Add(Me.TMuestrasGraf6)
        Me.Panel12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel12.Location = New System.Drawing.Point(507, 668)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(498, 26)
        Me.Panel12.TabIndex = 21
        '
        'BNext6
        '
        Me.BNext6.Image = CType(resources.GetObject("BNext6.Image"), System.Drawing.Image)
        Me.BNext6.Location = New System.Drawing.Point(461, -6)
        Me.BNext6.Name = "BNext6"
        Me.BNext6.Size = New System.Drawing.Size(39, 30)
        Me.BNext6.TabIndex = 5
        Me.BNext6.UseVisualStyleBackColor = True
        '
        'BPrevious6
        '
        Me.BPrevious6.Image = CType(resources.GetObject("BPrevious6.Image"), System.Drawing.Image)
        Me.BPrevious6.Location = New System.Drawing.Point(5, -5)
        Me.BPrevious6.Name = "BPrevious6"
        Me.BPrevious6.Size = New System.Drawing.Size(40, 29)
        Me.BPrevious6.TabIndex = 4
        Me.BPrevious6.UseVisualStyleBackColor = True
        '
        'TFechaIni6
        '
        Me.TFechaIni6.Location = New System.Drawing.Point(43, -1)
        Me.TFechaIni6.Name = "TFechaIni6"
        Me.TFechaIni6.Size = New System.Drawing.Size(100, 20)
        Me.TFechaIni6.TabIndex = 3
        '
        'TFechaFin6
        '
        Me.TFechaFin6.Location = New System.Drawing.Point(360, -1)
        Me.TFechaFin6.Name = "TFechaFin6"
        Me.TFechaFin6.Size = New System.Drawing.Size(100, 20)
        Me.TFechaFin6.TabIndex = 2
        '
        'TMuestrasDia6
        '
        Me.TMuestrasDia6.Location = New System.Drawing.Point(255, -1)
        Me.TMuestrasDia6.Name = "TMuestrasDia6"
        Me.TMuestrasDia6.Size = New System.Drawing.Size(100, 20)
        Me.TMuestrasDia6.TabIndex = 1
        Me.TMuestrasDia6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TMuestrasGraf6
        '
        Me.TMuestrasGraf6.Location = New System.Drawing.Point(151, -1)
        Me.TMuestrasGraf6.Name = "TMuestrasGraf6"
        Me.TMuestrasGraf6.Size = New System.Drawing.Size(100, 20)
        Me.TMuestrasGraf6.TabIndex = 0
        Me.TMuestrasGraf6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel11
        '
        Me.Panel11.Controls.Add(Me.BNext3)
        Me.Panel11.Controls.Add(Me.BPrevious3)
        Me.Panel11.Controls.Add(Me.TFechaIni3)
        Me.Panel11.Controls.Add(Me.TFechaFin3)
        Me.Panel11.Controls.Add(Me.TMuestrasDia3)
        Me.Panel11.Controls.Add(Me.TMuestrasGraf3)
        Me.Panel11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel11.Location = New System.Drawing.Point(3, 668)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(498, 26)
        Me.Panel11.TabIndex = 20
        '
        'BNext3
        '
        Me.BNext3.Image = CType(resources.GetObject("BNext3.Image"), System.Drawing.Image)
        Me.BNext3.Location = New System.Drawing.Point(461, -6)
        Me.BNext3.Name = "BNext3"
        Me.BNext3.Size = New System.Drawing.Size(39, 30)
        Me.BNext3.TabIndex = 5
        Me.BNext3.UseVisualStyleBackColor = True
        '
        'BPrevious3
        '
        Me.BPrevious3.Image = CType(resources.GetObject("BPrevious3.Image"), System.Drawing.Image)
        Me.BPrevious3.Location = New System.Drawing.Point(5, -5)
        Me.BPrevious3.Name = "BPrevious3"
        Me.BPrevious3.Size = New System.Drawing.Size(40, 29)
        Me.BPrevious3.TabIndex = 4
        Me.BPrevious3.UseVisualStyleBackColor = True
        '
        'TFechaIni3
        '
        Me.TFechaIni3.Location = New System.Drawing.Point(43, -1)
        Me.TFechaIni3.Name = "TFechaIni3"
        Me.TFechaIni3.Size = New System.Drawing.Size(100, 20)
        Me.TFechaIni3.TabIndex = 3
        '
        'TFechaFin3
        '
        Me.TFechaFin3.Location = New System.Drawing.Point(360, -1)
        Me.TFechaFin3.Name = "TFechaFin3"
        Me.TFechaFin3.Size = New System.Drawing.Size(100, 20)
        Me.TFechaFin3.TabIndex = 2
        '
        'TMuestrasDia3
        '
        Me.TMuestrasDia3.Location = New System.Drawing.Point(255, -1)
        Me.TMuestrasDia3.Name = "TMuestrasDia3"
        Me.TMuestrasDia3.Size = New System.Drawing.Size(100, 20)
        Me.TMuestrasDia3.TabIndex = 1
        Me.TMuestrasDia3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TMuestrasGraf3
        '
        Me.TMuestrasGraf3.Location = New System.Drawing.Point(151, -1)
        Me.TMuestrasGraf3.Name = "TMuestrasGraf3"
        Me.TMuestrasGraf3.Size = New System.Drawing.Size(100, 20)
        Me.TMuestrasGraf3.TabIndex = 0
        Me.TMuestrasGraf3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.Color.Wheat
        Me.Panel10.Controls.Add(Me.Label24)
        Me.Panel10.Controls.Add(Me.Label25)
        Me.Panel10.Controls.Add(Me.Label26)
        Me.Panel10.Controls.Add(Me.Label27)
        Me.Panel10.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel10.Location = New System.Drawing.Point(507, 653)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(498, 9)
        Me.Panel10.TabIndex = 19
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(374, -2)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(62, 13)
        Me.Label24.TabIndex = 3
        Me.Label24.Text = "Fecha Final"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(270, -2)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(71, 13)
        Me.Label25.TabIndex = 2
        Me.Label25.Text = "Muestras Día"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(168, -2)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(76, 13)
        Me.Label26.TabIndex = 1
        Me.Label26.Text = "Muestras Gráf."
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(62, -2)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(67, 13)
        Me.Label27.TabIndex = 0
        Me.Label27.Text = "Fecha Inicial"
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.Color.Wheat
        Me.Panel9.Controls.Add(Me.Label20)
        Me.Panel9.Controls.Add(Me.Label21)
        Me.Panel9.Controls.Add(Me.Label22)
        Me.Panel9.Controls.Add(Me.Label23)
        Me.Panel9.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel9.Location = New System.Drawing.Point(3, 653)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(498, 9)
        Me.Panel9.TabIndex = 18
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(374, -2)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(62, 13)
        Me.Label20.TabIndex = 3
        Me.Label20.Text = "Fecha Final"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(270, -2)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(71, 13)
        Me.Label21.TabIndex = 2
        Me.Label21.Text = "Muestras Día"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(168, -2)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(76, 13)
        Me.Label22.TabIndex = 1
        Me.Label22.Text = "Muestras Gráf."
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(62, -2)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(67, 13)
        Me.Label23.TabIndex = 0
        Me.Label23.Text = "Fecha Inicial"
        '
        'ChDatos6
        '
        Me.ChDatos6.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ChDatos6.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.DiagonalRight
        ChartArea2.AxisX.IsLabelAutoFit = False
        ChartArea2.AxisX.MajorGrid.Enabled = False
        ChartArea2.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash
        ChartArea2.AxisX2.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash
        ChartArea2.AxisX2.MajorTickMark.Enabled = False
        ChartArea2.AxisY.MajorGrid.Enabled = False
        ChartArea2.Name = "ChartArea1"
        Me.ChDatos6.ChartAreas.Add(ChartArea2)
        Me.ChDatos6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ChDatos6.Location = New System.Drawing.Point(507, 463)
        Me.ChDatos6.Name = "ChDatos6"
        Me.ChDatos6.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Bright
        Series2.BorderWidth = 3
        Series2.ChartArea = "ChartArea1"
        Series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine
        Series2.IsValueShownAsLabel = True
        Series2.IsVisibleInLegend = False
        Series2.Name = "Series1"
        Me.ChDatos6.Series.Add(Series2)
        Me.ChDatos6.Size = New System.Drawing.Size(498, 184)
        Me.ChDatos6.TabIndex = 17
        Me.ChDatos6.Text = "BOQUILLA 1"
        Title2.DockedToChartArea = "ChartArea1"
        Title2.Name = "Title1"
        Me.ChDatos6.Titles.Add(Title2)
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.Color.Wheat
        Me.Panel8.Controls.Add(Me.Label16)
        Me.Panel8.Controls.Add(Me.Label17)
        Me.Panel8.Controls.Add(Me.Label18)
        Me.Panel8.Controls.Add(Me.Label19)
        Me.Panel8.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel8.Location = New System.Drawing.Point(507, 423)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(498, 9)
        Me.Panel8.TabIndex = 16
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(374, -2)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(62, 13)
        Me.Label16.TabIndex = 3
        Me.Label16.Text = "Fecha Final"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(270, -2)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(71, 13)
        Me.Label17.TabIndex = 2
        Me.Label17.Text = "Muestras Día"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(168, -2)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(76, 13)
        Me.Label18.TabIndex = 1
        Me.Label18.Text = "Muestras Gráf."
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(62, -2)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(67, 13)
        Me.Label19.TabIndex = 0
        Me.Label19.Text = "Fecha Inicial"
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.BNext5)
        Me.Panel7.Controls.Add(Me.BPrevious5)
        Me.Panel7.Controls.Add(Me.TFechaIni5)
        Me.Panel7.Controls.Add(Me.TFechaFin5)
        Me.Panel7.Controls.Add(Me.TMuestrasDia5)
        Me.Panel7.Controls.Add(Me.TMuestrasGraf5)
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel7.Location = New System.Drawing.Point(507, 438)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(498, 19)
        Me.Panel7.TabIndex = 15
        '
        'BNext5
        '
        Me.BNext5.Image = CType(resources.GetObject("BNext5.Image"), System.Drawing.Image)
        Me.BNext5.Location = New System.Drawing.Point(461, -6)
        Me.BNext5.Name = "BNext5"
        Me.BNext5.Size = New System.Drawing.Size(39, 30)
        Me.BNext5.TabIndex = 5
        Me.BNext5.UseVisualStyleBackColor = True
        '
        'BPrevious5
        '
        Me.BPrevious5.Image = CType(resources.GetObject("BPrevious5.Image"), System.Drawing.Image)
        Me.BPrevious5.Location = New System.Drawing.Point(5, -5)
        Me.BPrevious5.Name = "BPrevious5"
        Me.BPrevious5.Size = New System.Drawing.Size(40, 29)
        Me.BPrevious5.TabIndex = 4
        Me.BPrevious5.UseVisualStyleBackColor = True
        '
        'TFechaIni5
        '
        Me.TFechaIni5.Location = New System.Drawing.Point(43, -1)
        Me.TFechaIni5.Name = "TFechaIni5"
        Me.TFechaIni5.Size = New System.Drawing.Size(100, 20)
        Me.TFechaIni5.TabIndex = 3
        '
        'TFechaFin5
        '
        Me.TFechaFin5.Location = New System.Drawing.Point(360, -1)
        Me.TFechaFin5.Name = "TFechaFin5"
        Me.TFechaFin5.Size = New System.Drawing.Size(100, 20)
        Me.TFechaFin5.TabIndex = 2
        '
        'TMuestrasDia5
        '
        Me.TMuestrasDia5.Location = New System.Drawing.Point(255, -1)
        Me.TMuestrasDia5.Name = "TMuestrasDia5"
        Me.TMuestrasDia5.Size = New System.Drawing.Size(100, 20)
        Me.TMuestrasDia5.TabIndex = 1
        Me.TMuestrasDia5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TMuestrasGraf5
        '
        Me.TMuestrasGraf5.Location = New System.Drawing.Point(151, -1)
        Me.TMuestrasGraf5.Name = "TMuestrasGraf5"
        Me.TMuestrasGraf5.Size = New System.Drawing.Size(100, 20)
        Me.TMuestrasGraf5.TabIndex = 0
        Me.TMuestrasGraf5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.BNext2)
        Me.Panel2.Controls.Add(Me.BPrevious2)
        Me.Panel2.Controls.Add(Me.TFechaIni2)
        Me.Panel2.Controls.Add(Me.TFechaFin2)
        Me.Panel2.Controls.Add(Me.TMuestrasDia2)
        Me.Panel2.Controls.Add(Me.TMuestrasGraf2)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 438)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(498, 19)
        Me.Panel2.TabIndex = 14
        '
        'BNext2
        '
        Me.BNext2.Image = CType(resources.GetObject("BNext2.Image"), System.Drawing.Image)
        Me.BNext2.Location = New System.Drawing.Point(461, -6)
        Me.BNext2.Name = "BNext2"
        Me.BNext2.Size = New System.Drawing.Size(39, 30)
        Me.BNext2.TabIndex = 5
        Me.BNext2.UseVisualStyleBackColor = True
        '
        'BPrevious2
        '
        Me.BPrevious2.Image = CType(resources.GetObject("BPrevious2.Image"), System.Drawing.Image)
        Me.BPrevious2.Location = New System.Drawing.Point(5, -5)
        Me.BPrevious2.Name = "BPrevious2"
        Me.BPrevious2.Size = New System.Drawing.Size(40, 29)
        Me.BPrevious2.TabIndex = 4
        Me.BPrevious2.UseVisualStyleBackColor = True
        '
        'TFechaIni2
        '
        Me.TFechaIni2.Location = New System.Drawing.Point(43, -1)
        Me.TFechaIni2.Name = "TFechaIni2"
        Me.TFechaIni2.Size = New System.Drawing.Size(100, 20)
        Me.TFechaIni2.TabIndex = 3
        '
        'TFechaFin2
        '
        Me.TFechaFin2.Location = New System.Drawing.Point(360, -1)
        Me.TFechaFin2.Name = "TFechaFin2"
        Me.TFechaFin2.Size = New System.Drawing.Size(100, 20)
        Me.TFechaFin2.TabIndex = 2
        '
        'TMuestrasDia2
        '
        Me.TMuestrasDia2.Location = New System.Drawing.Point(255, -1)
        Me.TMuestrasDia2.Name = "TMuestrasDia2"
        Me.TMuestrasDia2.Size = New System.Drawing.Size(100, 20)
        Me.TMuestrasDia2.TabIndex = 1
        Me.TMuestrasDia2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TMuestrasGraf2
        '
        Me.TMuestrasGraf2.Location = New System.Drawing.Point(151, -1)
        Me.TMuestrasGraf2.Name = "TMuestrasGraf2"
        Me.TMuestrasGraf2.Size = New System.Drawing.Size(100, 20)
        Me.TMuestrasGraf2.TabIndex = 0
        Me.TMuestrasGraf2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Wheat
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(3, 423)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(498, 9)
        Me.Panel1.TabIndex = 13
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(374, -2)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(62, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Fecha Final"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(270, -2)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Muestras Día"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(168, -2)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(76, 13)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Muestras Gráf."
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(62, -2)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(67, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Fecha Inicial"
        '
        'ChDatos3
        '
        Me.ChDatos3.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ChDatos3.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.DiagonalRight
        ChartArea3.AxisX.IsLabelAutoFit = False
        ChartArea3.AxisX.MajorGrid.Enabled = False
        ChartArea3.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash
        ChartArea3.AxisX2.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash
        ChartArea3.AxisX2.MajorTickMark.Enabled = False
        ChartArea3.AxisY.MajorGrid.Enabled = False
        ChartArea3.Name = "ChartArea1"
        Me.ChDatos3.ChartAreas.Add(ChartArea3)
        Me.ChDatos3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ChDatos3.Location = New System.Drawing.Point(3, 463)
        Me.ChDatos3.Name = "ChDatos3"
        Me.ChDatos3.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Bright
        Series3.BorderWidth = 3
        Series3.ChartArea = "ChartArea1"
        Series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine
        Series3.IsValueShownAsLabel = True
        Series3.IsVisibleInLegend = False
        Series3.Name = "Series1"
        Me.ChDatos3.Series.Add(Series3)
        Me.ChDatos3.Size = New System.Drawing.Size(498, 184)
        Me.ChDatos3.TabIndex = 12
        Me.ChDatos3.Text = "BOQUILLA 1"
        Title3.DockedToChartArea = "ChartArea1"
        Title3.Name = "Title1"
        Me.ChDatos3.Titles.Add(Title3)
        '
        'ChDatos5
        '
        Me.ChDatos5.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ChDatos5.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.DiagonalRight
        ChartArea4.AxisX.IsLabelAutoFit = False
        ChartArea4.AxisX.MajorGrid.Enabled = False
        ChartArea4.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash
        ChartArea4.AxisX2.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash
        ChartArea4.AxisX2.MajorTickMark.Enabled = False
        ChartArea4.AxisY.MajorGrid.Enabled = False
        ChartArea4.Name = "ChartArea1"
        Me.ChDatos5.ChartAreas.Add(ChartArea4)
        Me.ChDatos5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ChDatos5.Location = New System.Drawing.Point(507, 233)
        Me.ChDatos5.Name = "ChDatos5"
        Me.ChDatos5.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Bright
        Series4.BorderWidth = 3
        Series4.ChartArea = "ChartArea1"
        Series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine
        Series4.IsValueShownAsLabel = True
        Series4.IsVisibleInLegend = False
        Series4.Name = "Series1"
        Me.ChDatos5.Series.Add(Series4)
        Me.ChDatos5.Size = New System.Drawing.Size(498, 184)
        Me.ChDatos5.TabIndex = 11
        Me.ChDatos5.Text = "BOQUILLA 1"
        Title4.DockedToChartArea = "ChartArea1"
        Title4.Name = "Title1"
        Me.ChDatos5.Titles.Add(Title4)
        '
        'ChDatos2
        '
        Me.ChDatos2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ChDatos2.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.DiagonalRight
        ChartArea5.AxisX.IsLabelAutoFit = False
        ChartArea5.AxisX.MajorGrid.Enabled = False
        ChartArea5.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash
        ChartArea5.AxisX2.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash
        ChartArea5.AxisX2.MajorTickMark.Enabled = False
        ChartArea5.AxisY.MajorGrid.Enabled = False
        ChartArea5.Name = "ChartArea1"
        Me.ChDatos2.ChartAreas.Add(ChartArea5)
        Me.ChDatos2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ChDatos2.Location = New System.Drawing.Point(3, 233)
        Me.ChDatos2.Name = "ChDatos2"
        Me.ChDatos2.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Bright
        Series5.BorderWidth = 3
        Series5.ChartArea = "ChartArea1"
        Series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine
        Series5.IsValueShownAsLabel = True
        Series5.IsVisibleInLegend = False
        Series5.Name = "Series1"
        Me.ChDatos2.Series.Add(Series5)
        Me.ChDatos2.Size = New System.Drawing.Size(498, 184)
        Me.ChDatos2.TabIndex = 10
        Me.ChDatos2.Text = "BOQUILLA 1"
        Title5.DockedToChartArea = "ChartArea1"
        Title5.Name = "Title1"
        Me.ChDatos2.Titles.Add(Title5)
        '
        'ChDatos4
        '
        Me.ChDatos4.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ChDatos4.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.DiagonalRight
        ChartArea6.AxisX.IsLabelAutoFit = False
        ChartArea6.AxisX.MajorGrid.Enabled = False
        ChartArea6.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash
        ChartArea6.AxisX2.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash
        ChartArea6.AxisX2.MajorTickMark.Enabled = False
        ChartArea6.AxisY.MajorGrid.Enabled = False
        ChartArea6.Name = "ChartArea1"
        Me.ChDatos4.ChartAreas.Add(ChartArea6)
        Me.ChDatos4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ChDatos4.Location = New System.Drawing.Point(507, 3)
        Me.ChDatos4.Name = "ChDatos4"
        Me.ChDatos4.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Bright
        Series6.BorderWidth = 3
        Series6.ChartArea = "ChartArea1"
        Series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine
        Series6.IsValueShownAsLabel = True
        Series6.IsVisibleInLegend = False
        Series6.Name = "Series1"
        Me.ChDatos4.Series.Add(Series6)
        Me.ChDatos4.Size = New System.Drawing.Size(498, 184)
        Me.ChDatos4.TabIndex = 9
        Me.ChDatos4.Text = "BOQUILLA 1"
        Title6.DockedToChartArea = "ChartArea1"
        Title6.Name = "Title1"
        Me.ChDatos4.Titles.Add(Title6)
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.Wheat
        Me.Panel6.Controls.Add(Me.Label12)
        Me.Panel6.Controls.Add(Me.Label13)
        Me.Panel6.Controls.Add(Me.Label14)
        Me.Panel6.Controls.Add(Me.Label15)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel6.Location = New System.Drawing.Point(507, 193)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(498, 9)
        Me.Panel6.TabIndex = 8
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(374, -2)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(62, 13)
        Me.Label12.TabIndex = 3
        Me.Label12.Text = "Fecha Final"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(270, -2)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(71, 13)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "Muestras Día"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(168, -2)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(76, 13)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "Muestras Gráf."
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(62, -2)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(67, 13)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "Fecha Inicial"
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.BNext4)
        Me.Panel5.Controls.Add(Me.BPrevious4)
        Me.Panel5.Controls.Add(Me.TFechaIni4)
        Me.Panel5.Controls.Add(Me.TFechaFin4)
        Me.Panel5.Controls.Add(Me.TMuestrasDia4)
        Me.Panel5.Controls.Add(Me.TMuestrasGraf4)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel5.Location = New System.Drawing.Point(507, 208)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(498, 19)
        Me.Panel5.TabIndex = 7
        '
        'BNext4
        '
        Me.BNext4.Image = CType(resources.GetObject("BNext4.Image"), System.Drawing.Image)
        Me.BNext4.Location = New System.Drawing.Point(461, -6)
        Me.BNext4.Name = "BNext4"
        Me.BNext4.Size = New System.Drawing.Size(39, 30)
        Me.BNext4.TabIndex = 5
        Me.BNext4.UseVisualStyleBackColor = True
        '
        'BPrevious4
        '
        Me.BPrevious4.Image = CType(resources.GetObject("BPrevious4.Image"), System.Drawing.Image)
        Me.BPrevious4.Location = New System.Drawing.Point(5, -5)
        Me.BPrevious4.Name = "BPrevious4"
        Me.BPrevious4.Size = New System.Drawing.Size(40, 29)
        Me.BPrevious4.TabIndex = 4
        Me.BPrevious4.UseVisualStyleBackColor = True
        '
        'TFechaIni4
        '
        Me.TFechaIni4.Location = New System.Drawing.Point(43, -1)
        Me.TFechaIni4.Name = "TFechaIni4"
        Me.TFechaIni4.Size = New System.Drawing.Size(100, 20)
        Me.TFechaIni4.TabIndex = 3
        '
        'TFechaFin4
        '
        Me.TFechaFin4.Location = New System.Drawing.Point(360, -1)
        Me.TFechaFin4.Name = "TFechaFin4"
        Me.TFechaFin4.Size = New System.Drawing.Size(100, 20)
        Me.TFechaFin4.TabIndex = 2
        '
        'TMuestrasDia4
        '
        Me.TMuestrasDia4.Location = New System.Drawing.Point(255, -1)
        Me.TMuestrasDia4.Name = "TMuestrasDia4"
        Me.TMuestrasDia4.Size = New System.Drawing.Size(100, 20)
        Me.TMuestrasDia4.TabIndex = 1
        Me.TMuestrasDia4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TMuestrasGraf4
        '
        Me.TMuestrasGraf4.Location = New System.Drawing.Point(151, -1)
        Me.TMuestrasGraf4.Name = "TMuestrasGraf4"
        Me.TMuestrasGraf4.Size = New System.Drawing.Size(100, 20)
        Me.TMuestrasGraf4.TabIndex = 0
        Me.TMuestrasGraf4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.BNext1)
        Me.Panel4.Controls.Add(Me.BPrevious1)
        Me.Panel4.Controls.Add(Me.TFechaIni1)
        Me.Panel4.Controls.Add(Me.TFechaFin1)
        Me.Panel4.Controls.Add(Me.TMuestrasDia1)
        Me.Panel4.Controls.Add(Me.TMuestrasGraf1)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Location = New System.Drawing.Point(3, 208)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(498, 19)
        Me.Panel4.TabIndex = 6
        '
        'BNext1
        '
        Me.BNext1.Image = CType(resources.GetObject("BNext1.Image"), System.Drawing.Image)
        Me.BNext1.Location = New System.Drawing.Point(461, -6)
        Me.BNext1.Name = "BNext1"
        Me.BNext1.Size = New System.Drawing.Size(39, 30)
        Me.BNext1.TabIndex = 5
        Me.BNext1.UseVisualStyleBackColor = True
        '
        'BPrevious1
        '
        Me.BPrevious1.Image = CType(resources.GetObject("BPrevious1.Image"), System.Drawing.Image)
        Me.BPrevious1.Location = New System.Drawing.Point(5, -5)
        Me.BPrevious1.Name = "BPrevious1"
        Me.BPrevious1.Size = New System.Drawing.Size(40, 29)
        Me.BPrevious1.TabIndex = 4
        Me.BPrevious1.UseVisualStyleBackColor = True
        '
        'TFechaIni1
        '
        Me.TFechaIni1.Location = New System.Drawing.Point(43, -1)
        Me.TFechaIni1.Name = "TFechaIni1"
        Me.TFechaIni1.Size = New System.Drawing.Size(100, 20)
        Me.TFechaIni1.TabIndex = 3
        '
        'TFechaFin1
        '
        Me.TFechaFin1.Location = New System.Drawing.Point(360, -1)
        Me.TFechaFin1.Name = "TFechaFin1"
        Me.TFechaFin1.Size = New System.Drawing.Size(100, 20)
        Me.TFechaFin1.TabIndex = 2
        '
        'TMuestrasDia1
        '
        Me.TMuestrasDia1.Location = New System.Drawing.Point(255, -1)
        Me.TMuestrasDia1.Name = "TMuestrasDia1"
        Me.TMuestrasDia1.Size = New System.Drawing.Size(100, 20)
        Me.TMuestrasDia1.TabIndex = 1
        Me.TMuestrasDia1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TMuestrasGraf1
        '
        Me.TMuestrasGraf1.Location = New System.Drawing.Point(151, -1)
        Me.TMuestrasGraf1.Name = "TMuestrasGraf1"
        Me.TMuestrasGraf1.Size = New System.Drawing.Size(100, 20)
        Me.TMuestrasGraf1.TabIndex = 0
        Me.TMuestrasGraf1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Wheat
        Me.Panel3.Controls.Add(Me.Label6)
        Me.Panel3.Controls.Add(Me.Label7)
        Me.Panel3.Controls.Add(Me.Label8)
        Me.Panel3.Controls.Add(Me.Label9)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel3.Location = New System.Drawing.Point(3, 193)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(498, 9)
        Me.Panel3.TabIndex = 5
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(374, -2)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(62, 13)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "Fecha Final"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(270, -2)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(71, 13)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Muestras Día"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(168, -2)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(76, 13)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "Muestras Gráf."
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(62, -2)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(67, 13)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Fecha Inicial"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(6, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(128, 15)
        Me.Label2.TabIndex = 35
        Me.Label2.Text = "INTERVALO GRÁFICAS:"
        '
        'TimSeg
        '
        Me.TimSeg.Interval = 1000
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.OPHora1)
        Me.GroupBox1.Controls.Add(Me.OPHora8)
        Me.GroupBox1.Controls.Add(Me.OPHora4)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(12, -2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(384, 30)
        Me.GroupBox1.TabIndex = 37
        Me.GroupBox1.TabStop = False
        '
        'OPHora1
        '
        Me.OPHora1.AutoSize = True
        Me.OPHora1.Checked = True
        Me.OPHora1.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OPHora1.Location = New System.Drawing.Point(171, 7)
        Me.OPHora1.Name = "OPHora1"
        Me.OPHora1.Size = New System.Drawing.Size(61, 19)
        Me.OPHora1.TabIndex = 37
        Me.OPHora1.TabStop = True
        Me.OPHora1.Text = "1 Hora"
        Me.OPHora1.UseVisualStyleBackColor = True
        '
        'OPHora8
        '
        Me.OPHora8.AutoSize = True
        Me.OPHora8.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OPHora8.Location = New System.Drawing.Point(310, 7)
        Me.OPHora8.Name = "OPHora8"
        Me.OPHora8.Size = New System.Drawing.Size(66, 19)
        Me.OPHora8.TabIndex = 39
        Me.OPHora8.TabStop = True
        Me.OPHora8.Text = "8 Horas"
        Me.OPHora8.UseVisualStyleBackColor = True
        '
        'OPHora4
        '
        Me.OPHora4.AutoSize = True
        Me.OPHora4.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OPHora4.Location = New System.Drawing.Point(242, 7)
        Me.OPHora4.Name = "OPHora4"
        Me.OPHora4.Size = New System.Drawing.Size(66, 19)
        Me.OPHora4.TabIndex = 38
        Me.OPHora4.TabStop = True
        Me.OPHora4.Text = "4 Horas"
        Me.OPHora4.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label29)
        Me.GroupBox2.Controls.Add(Me.Label28)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Location = New System.Drawing.Point(414, -2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(494, 30)
        Me.GroupBox2.TabIndex = 38
        Me.GroupBox2.TabStop = False
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(4, 9)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(99, 15)
        Me.Label29.TabIndex = 38
        Me.Label29.Text = "CONVENCIONES:"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.Color.Red
        Me.Label28.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.White
        Me.Label28.Location = New System.Drawing.Point(363, 9)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(104, 15)
        Me.Label28.TabIndex = 37
        Me.Label28.Text = "LÍMITES CONTROL"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label11.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(261, 9)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(65, 15)
        Me.Label11.TabIndex = 36
        Me.Label11.Text = "PESO REAL"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Green
        Me.Label10.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(128, 9)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(96, 15)
        Me.Label10.TabIndex = 35
        Me.Label10.Text = "PESO NOMINAL "
        '
        'BPlay
        '
        Me.BPlay.Image = CType(resources.GetObject("BPlay.Image"), System.Drawing.Image)
        Me.BPlay.Location = New System.Drawing.Point(914, 0)
        Me.BPlay.Name = "BPlay"
        Me.BPlay.Size = New System.Drawing.Size(44, 31)
        Me.BPlay.TabIndex = 39
        Me.BPlay.UseVisualStyleBackColor = True
        Me.BPlay.Visible = False
        '
        'GraficasProceso1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1008, 729)
        Me.Controls.Add(Me.BPlay)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.TPGraficos)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "GraficasProceso1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.TPGraficos.ResumeLayout(False)
        CType(Me.ChDatos1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout()
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        CType(Me.ChDatos6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.ChDatos3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ChDatos5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ChDatos2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ChDatos4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TPGraficos As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents BNext1 As System.Windows.Forms.Button
    Friend WithEvents BPrevious1 As System.Windows.Forms.Button
    Friend WithEvents TFechaIni1 As System.Windows.Forms.TextBox
    Friend WithEvents TFechaFin1 As System.Windows.Forms.TextBox
    Friend WithEvents TMuestrasDia1 As System.Windows.Forms.TextBox
    Friend WithEvents TMuestrasGraf1 As System.Windows.Forms.TextBox
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TimSeg As System.Windows.Forms.Timer
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents OPHora1 As System.Windows.Forms.RadioButton
    Friend WithEvents OPHora8 As System.Windows.Forms.RadioButton
    Friend WithEvents OPHora4 As System.Windows.Forms.RadioButton
    Friend WithEvents Panel12 As System.Windows.Forms.Panel
    Friend WithEvents BNext6 As System.Windows.Forms.Button
    Friend WithEvents BPrevious6 As System.Windows.Forms.Button
    Friend WithEvents TFechaIni6 As System.Windows.Forms.TextBox
    Friend WithEvents TFechaFin6 As System.Windows.Forms.TextBox
    Friend WithEvents TMuestrasDia6 As System.Windows.Forms.TextBox
    Friend WithEvents TMuestrasGraf6 As System.Windows.Forms.TextBox
    Friend WithEvents Panel11 As System.Windows.Forms.Panel
    Friend WithEvents BNext3 As System.Windows.Forms.Button
    Friend WithEvents BPrevious3 As System.Windows.Forms.Button
    Friend WithEvents TFechaIni3 As System.Windows.Forms.TextBox
    Friend WithEvents TFechaFin3 As System.Windows.Forms.TextBox
    Friend WithEvents TMuestrasDia3 As System.Windows.Forms.TextBox
    Friend WithEvents TMuestrasGraf3 As System.Windows.Forms.TextBox
    Friend WithEvents Panel10 As System.Windows.Forms.Panel
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents ChDatos6 As System.Windows.Forms.DataVisualization.Charting.Chart
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents BNext5 As System.Windows.Forms.Button
    Friend WithEvents BPrevious5 As System.Windows.Forms.Button
    Friend WithEvents TFechaIni5 As System.Windows.Forms.TextBox
    Friend WithEvents TFechaFin5 As System.Windows.Forms.TextBox
    Friend WithEvents TMuestrasDia5 As System.Windows.Forms.TextBox
    Friend WithEvents TMuestrasGraf5 As System.Windows.Forms.TextBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents BNext2 As System.Windows.Forms.Button
    Friend WithEvents BPrevious2 As System.Windows.Forms.Button
    Friend WithEvents TFechaIni2 As System.Windows.Forms.TextBox
    Friend WithEvents TFechaFin2 As System.Windows.Forms.TextBox
    Friend WithEvents TMuestrasDia2 As System.Windows.Forms.TextBox
    Friend WithEvents TMuestrasGraf2 As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents ChDatos3 As System.Windows.Forms.DataVisualization.Charting.Chart
    Friend WithEvents ChDatos5 As System.Windows.Forms.DataVisualization.Charting.Chart
    Friend WithEvents ChDatos2 As System.Windows.Forms.DataVisualization.Charting.Chart
    Friend WithEvents ChDatos4 As System.Windows.Forms.DataVisualization.Charting.Chart
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents BNext4 As System.Windows.Forms.Button
    Friend WithEvents BPrevious4 As System.Windows.Forms.Button
    Friend WithEvents TFechaIni4 As System.Windows.Forms.TextBox
    Friend WithEvents TFechaFin4 As System.Windows.Forms.TextBox
    Friend WithEvents TMuestrasDia4 As System.Windows.Forms.TextBox
    Friend WithEvents TMuestrasGraf4 As System.Windows.Forms.TextBox
    Friend WithEvents ChDatos1 As System.Windows.Forms.DataVisualization.Charting.Chart
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents BPlay As System.Windows.Forms.Button
End Class
