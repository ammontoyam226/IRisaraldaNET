﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Ensaque
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TBandChk1 = New System.Windows.Forms.TextBox()
        Me.TConsec1 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TSacUnder1 = New System.Windows.Forms.TextBox()
        Me.TSacOver1 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TStat1 = New System.Windows.Forms.TextBox()
        Me.TPesoTot1 = New System.Windows.Forms.TextBox()
        Me.TSacChk1 = New System.Windows.Forms.TextBox()
        Me.TPesoUlt1 = New System.Windows.Forms.TextBox()
        Me.TPesSac1 = New System.Windows.Forms.TextBox()
        Me.TPreset1 = New System.Windows.Forms.TextBox()
        Me.TLote1 = New System.Windows.Forms.TextBox()
        Me.TCodProd1 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TBandChk2 = New System.Windows.Forms.TextBox()
        Me.TConsec2 = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TSacUnder2 = New System.Windows.Forms.TextBox()
        Me.TSacOver2 = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.TStat2 = New System.Windows.Forms.TextBox()
        Me.TPesoTot2 = New System.Windows.Forms.TextBox()
        Me.TSacChk2 = New System.Windows.Forms.TextBox()
        Me.TPesoUlt2 = New System.Windows.Forms.TextBox()
        Me.TPesSac2 = New System.Windows.Forms.TextBox()
        Me.TPreset2 = New System.Windows.Forms.TextBox()
        Me.TLote2 = New System.Windows.Forms.TextBox()
        Me.TCodProd2 = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.TBandChk3 = New System.Windows.Forms.TextBox()
        Me.TConsec3 = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.TSacUnder3 = New System.Windows.Forms.TextBox()
        Me.TSacOver3 = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.TStat3 = New System.Windows.Forms.TextBox()
        Me.TPesoTot3 = New System.Windows.Forms.TextBox()
        Me.TSacChk3 = New System.Windows.Forms.TextBox()
        Me.TPesoUlt3 = New System.Windows.Forms.TextBox()
        Me.TPesSac3 = New System.Windows.Forms.TextBox()
        Me.TPreset3 = New System.Windows.Forms.TextBox()
        Me.TLote3 = New System.Windows.Forms.TextBox()
        Me.TCodProd3 = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'TBandChk1
        '
        Me.TBandChk1.Location = New System.Drawing.Point(76, 159)
        Me.TBandChk1.Name = "TBandChk1"
        Me.TBandChk1.Size = New System.Drawing.Size(56, 20)
        Me.TBandChk1.TabIndex = 50
        '
        'TConsec1
        '
        Me.TConsec1.Location = New System.Drawing.Point(76, 138)
        Me.TConsec1.Name = "TConsec1"
        Me.TConsec1.Size = New System.Drawing.Size(56, 20)
        Me.TConsec1.TabIndex = 49
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(17, 163)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(57, 13)
        Me.Label13.TabIndex = 48
        Me.Label13.Text = "Band. Chk"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(28, 142)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(46, 13)
        Me.Label14.TabIndex = 47
        Me.Label14.Text = "Consec."
        '
        'TSacUnder1
        '
        Me.TSacUnder1.Location = New System.Drawing.Point(76, 117)
        Me.TSacUnder1.Name = "TSacUnder1"
        Me.TSacUnder1.Size = New System.Drawing.Size(56, 20)
        Me.TSacUnder1.TabIndex = 46
        '
        'TSacOver1
        '
        Me.TSacOver1.Location = New System.Drawing.Point(76, 96)
        Me.TSacOver1.Name = "TSacOver1"
        Me.TSacOver1.Size = New System.Drawing.Size(56, 20)
        Me.TSacOver1.TabIndex = 45
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(13, 121)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(61, 13)
        Me.Label9.TabIndex = 44
        Me.Label9.Text = "Sac. Under"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(19, 100)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(55, 13)
        Me.Label11.TabIndex = 43
        Me.Label11.Text = "Sac. Over"
        '
        'TStat1
        '
        Me.TStat1.Location = New System.Drawing.Point(76, 243)
        Me.TStat1.Name = "TStat1"
        Me.TStat1.Size = New System.Drawing.Size(56, 20)
        Me.TStat1.TabIndex = 42
        '
        'TPesoTot1
        '
        Me.TPesoTot1.Location = New System.Drawing.Point(76, 222)
        Me.TPesoTot1.Name = "TPesoTot1"
        Me.TPesoTot1.Size = New System.Drawing.Size(56, 20)
        Me.TPesoTot1.TabIndex = 41
        '
        'TSacChk1
        '
        Me.TSacChk1.Location = New System.Drawing.Point(76, 201)
        Me.TSacChk1.Name = "TSacChk1"
        Me.TSacChk1.Size = New System.Drawing.Size(56, 20)
        Me.TSacChk1.TabIndex = 40
        '
        'TPesoUlt1
        '
        Me.TPesoUlt1.Location = New System.Drawing.Point(76, 180)
        Me.TPesoUlt1.Name = "TPesoUlt1"
        Me.TPesoUlt1.Size = New System.Drawing.Size(56, 20)
        Me.TPesoUlt1.TabIndex = 39
        '
        'TPesSac1
        '
        Me.TPesSac1.Location = New System.Drawing.Point(76, 75)
        Me.TPesSac1.Name = "TPesSac1"
        Me.TPesSac1.Size = New System.Drawing.Size(56, 20)
        Me.TPesSac1.TabIndex = 38
        '
        'TPreset1
        '
        Me.TPreset1.Location = New System.Drawing.Point(76, 54)
        Me.TPreset1.Name = "TPreset1"
        Me.TPreset1.Size = New System.Drawing.Size(56, 20)
        Me.TPreset1.TabIndex = 37
        '
        'TLote1
        '
        Me.TLote1.Location = New System.Drawing.Point(76, 33)
        Me.TLote1.Name = "TLote1"
        Me.TLote1.Size = New System.Drawing.Size(56, 20)
        Me.TLote1.TabIndex = 36
        '
        'TCodProd1
        '
        Me.TCodProd1.Location = New System.Drawing.Point(76, 12)
        Me.TCodProd1.Name = "TCodProd1"
        Me.TCodProd1.Size = New System.Drawing.Size(56, 20)
        Me.TCodProd1.TabIndex = 35
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(34, 247)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 13)
        Me.Label5.TabIndex = 34
        Me.Label5.Text = "Estado"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(15, 226)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(59, 13)
        Me.Label6.TabIndex = 33
        Me.Label6.Text = "Tot. Sacos"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(36, 205)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(38, 13)
        Me.Label7.TabIndex = 32
        Me.Label7.Text = "Check"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(38, 184)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(36, 13)
        Me.Label8.TabIndex = 31
        Me.Label8.Text = "Ultimo"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(18, 79)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 13)
        Me.Label3.TabIndex = 30
        Me.Label3.Text = "Peso Sac."
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(28, 58)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(46, 13)
        Me.Label4.TabIndex = 29
        Me.Label4.Text = "Present."
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(46, 37)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(28, 13)
        Me.Label2.TabIndex = 28
        Me.Label2.Text = "Lote"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(24, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(50, 13)
        Me.Label1.TabIndex = 27
        Me.Label1.Text = "Producto"
        '
        'TBandChk2
        '
        Me.TBandChk2.Location = New System.Drawing.Point(361, 159)
        Me.TBandChk2.Name = "TBandChk2"
        Me.TBandChk2.Size = New System.Drawing.Size(56, 20)
        Me.TBandChk2.TabIndex = 74
        '
        'TConsec2
        '
        Me.TConsec2.Location = New System.Drawing.Point(361, 138)
        Me.TConsec2.Name = "TConsec2"
        Me.TConsec2.Size = New System.Drawing.Size(56, 20)
        Me.TConsec2.TabIndex = 73
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(302, 163)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(57, 13)
        Me.Label10.TabIndex = 72
        Me.Label10.Text = "Band. Chk"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(313, 142)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(46, 13)
        Me.Label12.TabIndex = 71
        Me.Label12.Text = "Consec."
        '
        'TSacUnder2
        '
        Me.TSacUnder2.Location = New System.Drawing.Point(361, 117)
        Me.TSacUnder2.Name = "TSacUnder2"
        Me.TSacUnder2.Size = New System.Drawing.Size(56, 20)
        Me.TSacUnder2.TabIndex = 70
        '
        'TSacOver2
        '
        Me.TSacOver2.Location = New System.Drawing.Point(361, 96)
        Me.TSacOver2.Name = "TSacOver2"
        Me.TSacOver2.Size = New System.Drawing.Size(56, 20)
        Me.TSacOver2.TabIndex = 69
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(298, 121)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(61, 13)
        Me.Label15.TabIndex = 68
        Me.Label15.Text = "Sac. Under"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(304, 100)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(55, 13)
        Me.Label16.TabIndex = 67
        Me.Label16.Text = "Sac. Over"
        '
        'TStat2
        '
        Me.TStat2.Location = New System.Drawing.Point(361, 243)
        Me.TStat2.Name = "TStat2"
        Me.TStat2.Size = New System.Drawing.Size(56, 20)
        Me.TStat2.TabIndex = 66
        '
        'TPesoTot2
        '
        Me.TPesoTot2.Location = New System.Drawing.Point(361, 222)
        Me.TPesoTot2.Name = "TPesoTot2"
        Me.TPesoTot2.Size = New System.Drawing.Size(56, 20)
        Me.TPesoTot2.TabIndex = 65
        '
        'TSacChk2
        '
        Me.TSacChk2.Location = New System.Drawing.Point(361, 201)
        Me.TSacChk2.Name = "TSacChk2"
        Me.TSacChk2.Size = New System.Drawing.Size(56, 20)
        Me.TSacChk2.TabIndex = 64
        '
        'TPesoUlt2
        '
        Me.TPesoUlt2.Location = New System.Drawing.Point(361, 180)
        Me.TPesoUlt2.Name = "TPesoUlt2"
        Me.TPesoUlt2.Size = New System.Drawing.Size(56, 20)
        Me.TPesoUlt2.TabIndex = 63
        '
        'TPesSac2
        '
        Me.TPesSac2.Location = New System.Drawing.Point(361, 75)
        Me.TPesSac2.Name = "TPesSac2"
        Me.TPesSac2.Size = New System.Drawing.Size(56, 20)
        Me.TPesSac2.TabIndex = 62
        '
        'TPreset2
        '
        Me.TPreset2.Location = New System.Drawing.Point(361, 54)
        Me.TPreset2.Name = "TPreset2"
        Me.TPreset2.Size = New System.Drawing.Size(56, 20)
        Me.TPreset2.TabIndex = 61
        '
        'TLote2
        '
        Me.TLote2.Location = New System.Drawing.Point(361, 33)
        Me.TLote2.Name = "TLote2"
        Me.TLote2.Size = New System.Drawing.Size(56, 20)
        Me.TLote2.TabIndex = 60
        '
        'TCodProd2
        '
        Me.TCodProd2.Location = New System.Drawing.Point(361, 12)
        Me.TCodProd2.Name = "TCodProd2"
        Me.TCodProd2.Size = New System.Drawing.Size(56, 20)
        Me.TCodProd2.TabIndex = 59
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(319, 247)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(40, 13)
        Me.Label17.TabIndex = 58
        Me.Label17.Text = "Estado"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(300, 226)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(59, 13)
        Me.Label18.TabIndex = 57
        Me.Label18.Text = "Tot. Sacos"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(321, 205)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(38, 13)
        Me.Label19.TabIndex = 56
        Me.Label19.Text = "Check"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(323, 184)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(36, 13)
        Me.Label20.TabIndex = 55
        Me.Label20.Text = "Ultimo"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(303, 79)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(56, 13)
        Me.Label21.TabIndex = 54
        Me.Label21.Text = "Peso Sac."
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(313, 58)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(46, 13)
        Me.Label22.TabIndex = 53
        Me.Label22.Text = "Present."
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(331, 37)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(28, 13)
        Me.Label23.TabIndex = 52
        Me.Label23.Text = "Lote"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(309, 16)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(50, 13)
        Me.Label24.TabIndex = 51
        Me.Label24.Text = "Producto"
        '
        'TBandChk3
        '
        Me.TBandChk3.Location = New System.Drawing.Point(610, 160)
        Me.TBandChk3.Name = "TBandChk3"
        Me.TBandChk3.Size = New System.Drawing.Size(56, 20)
        Me.TBandChk3.TabIndex = 98
        '
        'TConsec3
        '
        Me.TConsec3.Location = New System.Drawing.Point(610, 139)
        Me.TConsec3.Name = "TConsec3"
        Me.TConsec3.Size = New System.Drawing.Size(56, 20)
        Me.TConsec3.TabIndex = 97
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(551, 164)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(57, 13)
        Me.Label25.TabIndex = 96
        Me.Label25.Text = "Band. Chk"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(562, 143)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(46, 13)
        Me.Label26.TabIndex = 95
        Me.Label26.Text = "Consec."
        '
        'TSacUnder3
        '
        Me.TSacUnder3.Location = New System.Drawing.Point(610, 118)
        Me.TSacUnder3.Name = "TSacUnder3"
        Me.TSacUnder3.Size = New System.Drawing.Size(56, 20)
        Me.TSacUnder3.TabIndex = 94
        '
        'TSacOver3
        '
        Me.TSacOver3.Location = New System.Drawing.Point(610, 97)
        Me.TSacOver3.Name = "TSacOver3"
        Me.TSacOver3.Size = New System.Drawing.Size(56, 20)
        Me.TSacOver3.TabIndex = 93
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(547, 122)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(61, 13)
        Me.Label27.TabIndex = 92
        Me.Label27.Text = "Sac. Under"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(553, 101)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(55, 13)
        Me.Label28.TabIndex = 91
        Me.Label28.Text = "Sac. Over"
        '
        'TStat3
        '
        Me.TStat3.Location = New System.Drawing.Point(610, 244)
        Me.TStat3.Name = "TStat3"
        Me.TStat3.Size = New System.Drawing.Size(56, 20)
        Me.TStat3.TabIndex = 90
        '
        'TPesoTot3
        '
        Me.TPesoTot3.Location = New System.Drawing.Point(610, 223)
        Me.TPesoTot3.Name = "TPesoTot3"
        Me.TPesoTot3.Size = New System.Drawing.Size(56, 20)
        Me.TPesoTot3.TabIndex = 89
        '
        'TSacChk3
        '
        Me.TSacChk3.Location = New System.Drawing.Point(610, 202)
        Me.TSacChk3.Name = "TSacChk3"
        Me.TSacChk3.Size = New System.Drawing.Size(56, 20)
        Me.TSacChk3.TabIndex = 88
        '
        'TPesoUlt3
        '
        Me.TPesoUlt3.Location = New System.Drawing.Point(610, 181)
        Me.TPesoUlt3.Name = "TPesoUlt3"
        Me.TPesoUlt3.Size = New System.Drawing.Size(56, 20)
        Me.TPesoUlt3.TabIndex = 87
        '
        'TPesSac3
        '
        Me.TPesSac3.Location = New System.Drawing.Point(610, 76)
        Me.TPesSac3.Name = "TPesSac3"
        Me.TPesSac3.Size = New System.Drawing.Size(56, 20)
        Me.TPesSac3.TabIndex = 86
        '
        'TPreset3
        '
        Me.TPreset3.Location = New System.Drawing.Point(610, 55)
        Me.TPreset3.Name = "TPreset3"
        Me.TPreset3.Size = New System.Drawing.Size(56, 20)
        Me.TPreset3.TabIndex = 85
        '
        'TLote3
        '
        Me.TLote3.Location = New System.Drawing.Point(610, 34)
        Me.TLote3.Name = "TLote3"
        Me.TLote3.Size = New System.Drawing.Size(56, 20)
        Me.TLote3.TabIndex = 84
        '
        'TCodProd3
        '
        Me.TCodProd3.Location = New System.Drawing.Point(610, 13)
        Me.TCodProd3.Name = "TCodProd3"
        Me.TCodProd3.Size = New System.Drawing.Size(56, 20)
        Me.TCodProd3.TabIndex = 83
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(568, 248)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(40, 13)
        Me.Label29.TabIndex = 82
        Me.Label29.Text = "Estado"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(549, 227)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(59, 13)
        Me.Label30.TabIndex = 81
        Me.Label30.Text = "Tot. Sacos"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(570, 206)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(38, 13)
        Me.Label31.TabIndex = 80
        Me.Label31.Text = "Check"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(572, 185)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(36, 13)
        Me.Label32.TabIndex = 79
        Me.Label32.Text = "Ultimo"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(552, 80)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(56, 13)
        Me.Label33.TabIndex = 78
        Me.Label33.Text = "Peso Sac."
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(562, 59)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(46, 13)
        Me.Label34.TabIndex = 77
        Me.Label34.Text = "Present."
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(580, 38)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(28, 13)
        Me.Label35.TabIndex = 76
        Me.Label35.Text = "Lote"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(558, 17)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(50, 13)
        Me.Label36.TabIndex = 75
        Me.Label36.Text = "Producto"
        '
        'Ensaque
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1042, 420)
        Me.Controls.Add(Me.TBandChk3)
        Me.Controls.Add(Me.TConsec3)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.TSacUnder3)
        Me.Controls.Add(Me.TSacOver3)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.TStat3)
        Me.Controls.Add(Me.TPesoTot3)
        Me.Controls.Add(Me.TSacChk3)
        Me.Controls.Add(Me.TPesoUlt3)
        Me.Controls.Add(Me.TPesSac3)
        Me.Controls.Add(Me.TPreset3)
        Me.Controls.Add(Me.TLote3)
        Me.Controls.Add(Me.TCodProd3)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.Label33)
        Me.Controls.Add(Me.Label34)
        Me.Controls.Add(Me.Label35)
        Me.Controls.Add(Me.Label36)
        Me.Controls.Add(Me.TBandChk2)
        Me.Controls.Add(Me.TConsec2)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.TSacUnder2)
        Me.Controls.Add(Me.TSacOver2)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.TStat2)
        Me.Controls.Add(Me.TPesoTot2)
        Me.Controls.Add(Me.TSacChk2)
        Me.Controls.Add(Me.TPesoUlt2)
        Me.Controls.Add(Me.TPesSac2)
        Me.Controls.Add(Me.TPreset2)
        Me.Controls.Add(Me.TLote2)
        Me.Controls.Add(Me.TCodProd2)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.TBandChk1)
        Me.Controls.Add(Me.TConsec1)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.TSacUnder1)
        Me.Controls.Add(Me.TSacOver1)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.TStat1)
        Me.Controls.Add(Me.TPesoTot1)
        Me.Controls.Add(Me.TSacChk1)
        Me.Controls.Add(Me.TPesoUlt1)
        Me.Controls.Add(Me.TPesSac1)
        Me.Controls.Add(Me.TPreset1)
        Me.Controls.Add(Me.TLote1)
        Me.Controls.Add(Me.TCodProd1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Ensaque"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TBandChk1 As System.Windows.Forms.TextBox
    Friend WithEvents TConsec1 As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents TSacUnder1 As System.Windows.Forms.TextBox
    Friend WithEvents TSacOver1 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents TStat1 As System.Windows.Forms.TextBox
    Friend WithEvents TPesoTot1 As System.Windows.Forms.TextBox
    Friend WithEvents TSacChk1 As System.Windows.Forms.TextBox
    Friend WithEvents TPesoUlt1 As System.Windows.Forms.TextBox
    Friend WithEvents TPesSac1 As System.Windows.Forms.TextBox
    Friend WithEvents TPreset1 As System.Windows.Forms.TextBox
    Friend WithEvents TLote1 As System.Windows.Forms.TextBox
    Friend WithEvents TCodProd1 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TBandChk2 As System.Windows.Forms.TextBox
    Friend WithEvents TConsec2 As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TSacUnder2 As System.Windows.Forms.TextBox
    Friend WithEvents TSacOver2 As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents TStat2 As System.Windows.Forms.TextBox
    Friend WithEvents TPesoTot2 As System.Windows.Forms.TextBox
    Friend WithEvents TSacChk2 As System.Windows.Forms.TextBox
    Friend WithEvents TPesoUlt2 As System.Windows.Forms.TextBox
    Friend WithEvents TPesSac2 As System.Windows.Forms.TextBox
    Friend WithEvents TPreset2 As System.Windows.Forms.TextBox
    Friend WithEvents TLote2 As System.Windows.Forms.TextBox
    Friend WithEvents TCodProd2 As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents TBandChk3 As System.Windows.Forms.TextBox
    Friend WithEvents TConsec3 As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents TSacUnder3 As System.Windows.Forms.TextBox
    Friend WithEvents TSacOver3 As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents TStat3 As System.Windows.Forms.TextBox
    Friend WithEvents TPesoTot3 As System.Windows.Forms.TextBox
    Friend WithEvents TSacChk3 As System.Windows.Forms.TextBox
    Friend WithEvents TPesoUlt3 As System.Windows.Forms.TextBox
    Friend WithEvents TPesSac3 As System.Windows.Forms.TextBox
    Friend WithEvents TPreset3 As System.Windows.Forms.TextBox
    Friend WithEvents TLote3 As System.Windows.Forms.TextBox
    Friend WithEvents TCodProd3 As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
End Class
